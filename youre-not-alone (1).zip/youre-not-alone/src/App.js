import React, { useState, useEffect } from "react";

const G = "linear-gradient(135deg,#F5A623 0%,#E879A0 45%,#8B5CF6 100%)";
const C = {
  bg: "#0F0A1E",
  card: "rgba(255,255,255,0.06)",
  border: "rgba(255,255,255,0.1)",
  text: "#F0EBF8",
  muted: "rgba(240,235,248,0.55)",
  pink: "#E879A0",
  purple: "#8B5CF6",
  gold: "#F5A623",
  lav: "#C4B5FD",
};

const HEAL_STAGES = [
  {
    id: 1,
    label: "Shock & Confusion",
    emoji: "😶",
    short: "At first, you're reeling — struggling to make sense of what happened.",
    detail:
      "At first, you're struggling to make sense of what happened. You might feel blindsided by their sudden coldness or distance, or confused about how love turned into cruelty. You replay everything, searching for answers.",
    color: "#F5A623",
  },
  {
    id: 2,
    label: "Grief & Withdrawal",
    emoji: "💧",
    short: "You start mourning what you thought the relationship was.",
    detail:
      "You start mourning what you thought the relationship was — not what it actually was. You miss the love-bombing days and crave a closure the narcissist will never give. This stage often feels like addiction withdrawal because of the trauma bond.",
    color: "#E879A0",
  },
  {
    id: 3,
    label: "Anger & Awareness",
    emoji: "🔥",
    short: "Your anger begins to surface — at them for their manipulation.",
    detail:
      "Your anger begins to surface — at them for the manipulation, and at yourself for tolerating it. But this anger is healthy. It helps break the illusion and rebuild your boundaries. You begin to see the patterns of coercion, gaslighting, and emotional abuse clearly.",
    color: "#8B5CF6",
  },
  {
    id: 4,
    label: "Acceptance & Reality",
    emoji: "🌿",
    short: "You stop making excuses for them and accept reality.",
    detail:
      "You stop making excuses for them. You accept that they won't change, that their love wasn't real in the healthy sense, and that your healing doesn't depend on their apology. You may still feel pain, but it's mixed with growing clarity and peace.",
    color: "#10B981",
  },
  {
    id: 5,
    label: "Detachment & Empowerment",
    emoji: "🕊️",
    short: "You stop obsessing and your focus shifts back to you.",
    detail:
      "This is the last stage. You stop obsessing about them and what went wrong. Your focus shifts back to you — your goals, your identity, your self-worth. You recognise the manipulation for what it was, and the emotional hooks no longer work. You might even feel indifference: not hate, not longing. That's when you know you're truly free. This stage isn't revenge or closure from them — it's emotional neutrality and self-reclamation.",
    color: "#C4B5FD",
  },
];

// Free users see the first 5; the rest are part of the premium library.
const AFFIRMATIONS = [
  { cat: "Worth", emoji: "💎", text: "You are worthy of love that doesn't hurt.", free: true },
  { cat: "Healing", emoji: "🌿", text: "Healing is not linear. Bad days don't erase progress.", free: true },
  { cat: "Strength", emoji: "🔥", text: "You survived something designed to break you.", free: true },
  { cat: "Truth", emoji: "💡", text: "You are not crazy. What you experienced was real.", free: true },
  { cat: "Future", emoji: "🕊️", text: "Your story doesn't end here.", free: true },
  { cat: "Worth", emoji: "💎", text: "Their inability to love you was never proof of your value.", free: false },
  { cat: "Truth", emoji: "💡", text: "Confusion was the tactic. Clarity is the recovery.", free: false },
  { cat: "Strength", emoji: "🔥", text: "Every boundary you keep is a muscle getting stronger.", free: false },
  { cat: "Healing", emoji: "🌿", text: "You are allowed to grieve and to grow at the same time.", free: false },
  { cat: "Future", emoji: "🕊️", text: "The peace you're building can't be taken from you.", free: false },
];

const PRICING = { monthly: "£7.99", yearly: "£49.99", lifetime: "£79.99" };

// === Trauma Bond Assessment ===
// A free, educational self-reflection tool — NOT a diagnosis. 20 items scored 0–4 give an
// overall band, five sub-scores, personalised insights, and a safety flag that points to
// the crisis resources when answers suggest someone is stuck in a harmful relationship.
// Kept free on purpose: like Crisis and Learn, a self-check that can surface danger should
// never sit behind the paywall.
const TB_SCALE = [
  { label: "Never", v: 0 },
  { label: "Rarely", v: 1 },
  { label: "Sometimes", v: 2 },
  { label: "Often", v: 3 },
  { label: "Almost always", v: 4 },
];

const TB_QUESTIONS = [
  "I stay in the relationship despite repeated emotional pain.",
  "I feel addicted to the person, even when I know the relationship is unhealthy.",
  "I make excuses for their hurtful behaviour.",
  "I find myself focusing on the good times and minimising the bad.",
  "I feel anxious or panicked when they don't contact me.",
  "They alternate between affection and emotional distance.",
  "I feel responsible for fixing the relationship.",
  "Friends or family have expressed concern about the relationship.",
  "I struggle to leave even after being hurt repeatedly.",
  "I feel emotionally dependent on them.",
  "They have lied, manipulated, or gaslighted me.",
  "I often blame myself for problems they created.",
  "I keep hoping they will return to how they were at the beginning.",
  "I feel relief and euphoria when they show affection after mistreating me.",
  "I have ignored my own needs to keep the relationship going.",
  "I have lost confidence or self-esteem during the relationship.",
  "I feel trapped but unable to walk away.",
  "I experience withdrawal-like symptoms when we are apart.",
  "I repeatedly return after breakups.",
  "The relationship feels like an emotional rollercoaster.",
];

// Every question maps to exactly one sub-scale (0-based question indices). Sub-scores are
// shown as percentages so scales with different lengths stay comparable.
// Note on "Difficulty Leaving": this is the inverse of the "recovery readiness" idea — a
// higher score here means more stuck, not more ready. Naming it this way keeps every bar
// reading the same direction (higher = stronger indicator). Rename if you prefer.
const TB_SUBSCALES = [
  {
    key: "dependency",
    label: "Emotional Dependency",
    color: C.pink,
    q: [1, 9, 12, 13],
    insight:
      "Your responses suggest a strong emotional dependency pattern. Building independent support systems may help reduce feelings of attachment.",
  },
  {
    key: "manipulation",
    label: "Manipulation & Control",
    color: C.purple,
    q: [2, 3, 5, 10, 11],
    insight:
      "Your responses suggest exposure to behaviours commonly associated with manipulation and emotional control.",
  },
  {
    key: "selfesteem",
    label: "Self-Esteem Impact",
    color: C.gold,
    q: [6, 7, 14, 15],
    insight:
      "Your wellbeing may have been placed behind the needs of the relationship. Rebuilding self-worth is an important part of recovery.",
  },
  {
    key: "separation",
    label: "Separation Anxiety",
    color: C.lav,
    q: [4, 17],
    insight:
      "You may feel intense distress when you're apart from this person. That pull is a recognised feature of trauma bonding — not a measure of how right the relationship is.",
  },
  {
    key: "leaving",
    label: "Difficulty Leaving",
    color: "#10B981",
    q: [0, 8, 16, 18, 19],
    insight:
      "You may find it especially hard to step away, even after being hurt repeatedly. Support from people you trust can make leaving feel more possible.",
  },
];

const TB_BANDS = [
  { max: 20, label: "Low indicators", blurb: "Few signs of a trauma bond are present.", color: "#10B981" },
  { max: 40, label: "Mild indicators", blurb: "Some unhealthy attachment patterns may exist.", color: C.gold },
  { max: 60, label: "Moderate indicators", blurb: "Several signs of a trauma bond are present. Further reflection and support may be beneficial.", color: C.pink },
  { max: 80, label: "Strong indicators", blurb: "The relationship shows many characteristics associated with trauma bonding.", color: C.purple },
];

const tbBand = (total) => TB_BANDS.find((b) => total <= b.max) || TB_BANDS[TB_BANDS.length - 1];
const tbSubBand = (pct) => (pct >= 66 ? "High" : pct >= 40 ? "Moderate" : "Low");

// === Red Flag Detector ===
// A private, on-device reflection aid. It scans wording for phrasing commonly linked to
// emotional manipulation and control, returns a risk score plus the patterns it noticed,
// and always routes to support. It is NOT a diagnosis and NOT proof of abuse — context
// matters, and only the person living it (with a trusted professional) can judge their
// situation. The tool deliberately errs toward caution: it can both over-flag normal
// messages and miss things. Everything runs locally, so the text never leaves the device.
//
// Upgrade path: to make detection deeper, route the message through the Companion proxy
// (CHAT_API_URL) for an AI pass and merge it into the same category structure shown below.

// Four-tier colour system used across the detector.
const RF_TIER_COLOR = { yellow: "#F5A623", orange: "#F97316", red: "#EF4444" };
const RF_TIER_RANK = { yellow: 1, orange: 2, red: 3 };

const RF_BANDS = [
  { max: 24, emoji: "🟢", label: "Healthy", color: "#10B981", why: "Nothing here stands out as manipulative. Healthy communication respects your feelings and your freedom to choose." },
  { max: 49, emoji: "🟡", label: "Concerning", color: "#F5A623", why: "A phrase or two here leans on pressure or guilt. Worth noticing how often this shows up — and how it leaves you feeling." },
  { max: 74, emoji: "🟠", label: "Manipulative", color: "#F97316", why: "This wording links affection to compliance and leans on guilt or control, which can create pressure, guilt, and dependency. Healthy relationships allow independence." },
  { max: 100, emoji: "🔴", label: "High-Risk", color: "#EF4444", why: "Several strong patterns of control, threats, or reality-distortion appear here. Please consider reaching out to someone you trust." },
];
const rfBand = (score) => RF_BANDS.find((b) => score <= b.max) || RF_BANDS[RF_BANDS.length - 1];

// Pattern library. Phrases are matched against lowercased text (curly apostrophes are
// normalised first). Kept deliberately specific to limit false positives on normal messages.
const RF_CATEGORIES = [
  {
    key: "lovebombing", label: "Love Bombing", tier: "orange",
    blurb: "Overwhelming affection or rushing the future, used to build fast attachment.",
    coach: "Real closeness builds over time. Does the intensity match how well you actually know each other yet?",
    patterns: ["you're my soulmate", "my soulmate", "never felt this way", "you're my everything", "move in together", "rest of my life with you", "you complete me", "we're meant to be", "love of my life", "you're perfect", "i can't live without you already"],
  },
  {
    key: "gaslighting", label: "Gaslighting", tier: "red",
    blurb: "Denying your reality or memory so you start to doubt yourself.",
    coach: "Trust your own memory. A caring partner doesn't need you to feel confused in order to feel right.",
    patterns: ["that never happened", "you're imagining", "you're crazy", "you're being crazy", "you're overreacting", "i never said that", "you're too sensitive", "you're remembering it wrong", "you're making things up", "that's not what happened", "you're paranoid", "stop being so dramatic", "no one will believe you"],
  },
  {
    key: "guilt", label: "Guilt-Tripping", tier: "orange",
    blurb: "Using guilt or a sense of debt to influence what you do.",
    coach: "Love isn't a debt. Would you ask someone you love to feel guilty for having needs of their own?",
    patterns: ["after everything i've done", "after all i've done for you", "i guess i don't matter", "you don't care about me", "i do everything for you", "you owe me", "you'd be lost without me", "i sacrificed everything", "i guess i'm just nothing"],
  },
  {
    key: "blameshift", label: "Blame-Shifting", tier: "orange",
    blurb: "Making you responsible for their hurtful behaviour.",
    coach: "You're not responsible for how someone chooses to treat you. Their reaction is their choice, not your fault.",
    patterns: ["look what you made me", "you made me do", "you forced me to", "this is your fault", "because you upset me", "if you hadn't", "you brought this on yourself", "you push me to it"],
  },
  {
    key: "control", label: "Control & Monitoring", tier: "red",
    blurb: "Directing or monitoring your choices, movements, or devices.",
    coach: "Independence is healthy. Does this feel like care — or like being watched?",
    patterns: ["send me your location", "share your location with me", "let me see your phone", "give me your password", "you're not allowed", "i don't want you going", "you can't go out", "i forbid you", "i need to check your phone", "track your phone", "you have to ask me first", "i decide who you"],
  },
  {
    key: "isolation", label: "Isolation", tier: "red",
    blurb: "Encouraging you to pull away from friends, family, or support.",
    coach: "Would you expect someone you love to give up the people who support them, just to prove it?",
    patterns: ["you don't need those friends", "you don't need anyone else", "need anyone else", "you don't need them", "your friends don't really", "your family doesn't really", "it's just you and me against", "choose between me and", "stop seeing your", "they're turning you against me", "i'm the only one who"],
  },
  {
    key: "conditional", label: "Conditional Love", tier: "orange",
    blurb: "Affection offered only when you comply.",
    coach: "Love that depends on obedience isn't really unconditional. What happens to the warmth when you say no?",
    patterns: ["if you loved me", "if you really loved me", "if you cared about me", "prove you love me", "you wouldn't if you loved me", "then i'll know you love me", "you'd do it if you loved me"],
  },
  {
    key: "withdrawal", label: "Punishment by Withdrawal", tier: "orange",
    blurb: "Using silence or withholding affection as a punishment.",
    coach: "Healthy partners say what hurt them directly, rather than using silence as punishment.",
    patterns: ["i only ignored you because", "that's why i ignored you", "i went quiet because you", "i'll talk to you when you", "you don't deserve my attention", "see how you like the silence", "i'm done talking to you until"],
  },
  {
    key: "threats", label: "Threats & Intimidation", tier: "red",
    blurb: "Threats about leaving, your worth, or your safety.",
    coach: "Threats are about power, not love. Your safety and peace matter — please reach out for support.",
    patterns: ["you'll regret", "nobody will ever love you", "no one else will want you", "you'll be sorry", "you can't survive without me", "you can't live without me", "i'll tell everyone", "you'll never see", "or you'll be sorry", "i'll make you pay"],
  },
  {
    key: "financial", label: "Financial Control", tier: "orange",
    blurb: "Restricting, monitoring, or demanding money and access to funds.",
    coach: "Financial freedom is part of safety. Are you free to access and decide on your own money?",
    patterns: ["give me your money", "why did you spend", "you can't spend", "i control the money", "you don't need a job", "ask me before you buy", "hand over your wages", "you have to account for every", "i decide what we spend"],
  },
];

const RF_HEALTHY_PATTERNS = ["take your time", "no pressure", "that's okay", "i respect your", "how do you feel", "i'm sorry", "i was wrong", "your choice", "whatever you're comfortable with", "i support you", "let's talk about it", "i appreciate you", "take all the time you need", "i understand if you", "it's okay to say no", "i'm proud of you"];

// Analyse a single message → { score, detected[], healthyHits, hasText }.
function rfAnalyze(raw) {
  const hasText = !!(raw || "").trim();
  const text = " " + (raw || "").toLowerCase().replace(/[\u2018\u2019]/g, "'") + " ";
  const detected = [];
  let score = 0;
  for (const cat of RF_CATEGORIES) {
    const hits = cat.patterns.filter((p) => text.includes(p));
    if (hits.length) {
      const base = cat.tier === "red" ? 36 : cat.tier === "orange" ? 26 : 16;
      const extra = Math.min((hits.length - 1) * 6, 18);
      score += base + extra;
      detected.push({ key: cat.key, label: cat.label, tier: cat.tier, blurb: cat.blurb, coach: cat.coach, hits: hits.length });
    }
  }
  const healthyHits = RF_HEALTHY_PATTERNS.filter((p) => text.includes(p)).length;
  if (detected.length) score -= Math.min(healthyHits * 8, 24);
  score = Math.max(0, Math.min(100, Math.round(score)));
  detected.sort((a, b) => RF_TIER_RANK[b.tier] - RF_TIER_RANK[a.tier]);
  return { score, detected, healthyHits, hasText };
}

// Analyse many messages (one per line) → category prevalence, average risk, trauma-bond flag.
function rfScan(raw) {
  const messages = (raw || "").split(/\n+/).map((m) => m.trim()).filter(Boolean);
  if (!messages.length) return null;
  const perMsg = messages.map((m) => ({ text: m, ...rfAnalyze(m) }));
  const N = messages.length;
  const cats = RF_CATEGORIES.map((cat) => {
    const count = perMsg.filter((r) => r.detected.some((d) => d.key === cat.key)).length;
    return { key: cat.key, label: cat.label, tier: cat.tier, color: RF_TIER_COLOR[cat.tier], pct: Math.round((count / N) * 100) };
  }).filter((c) => c.pct > 0).sort((a, b) => b.pct - a.pct);
  const healthyPct = Math.round((perMsg.filter((r) => r.healthyHits > 0).length / N) * 100);
  const avg = Math.round(perMsg.reduce((s, r) => s + r.score, 0) / N);
  const distinct = new Set();
  perMsg.forEach((r) => r.detected.forEach((d) => distinct.add(d.key)));
  const warm = perMsg.some((r) => r.detected.some((d) => d.key === "lovebombing") || r.healthyHits > 0);
  const cold = perMsg.some((r) => r.detected.some((d) => ["withdrawal", "threats", "control", "gaslighting"].includes(d.key)));
  const traumaBondFlag = distinct.size >= 3 || (warm && cold && distinct.size >= 1);
  return { messages, perMsg, cats, healthyPct, avg, N, traumaBondFlag };
}

// === RevenueCat Web Billing ===
// Setup:
//   1. npm install @revenuecat/purchases-js
//   2. In RevenueCat: connect a Stripe account, create a Web Billing app, and add an
//      entitlement with the exact ID below. Create an Offering with monthly / annual /
//      lifetime packages.
//   3. Paste your Web Billing PUBLIC key (starts with "rcb_") below.
// Leave REVENUECAT_WEB_KEY as "" to run in local testing mode (the paywall just unlocks
// locally so you can click through the gated screens before billing is live).
const REVENUECAT_WEB_KEY = ""; // e.g. "rcb_xxxxxxxxxxxxxxxx"
const PREMIUM_ENTITLEMENT = "premium"; // must match the entitlement ID in RevenueCat

// === AI Companion proxy ===
// The Companion talks to your server endpoint, never to Anthropic directly (which would
// leak your API key). Deploy api/chat.js and point this at it.
const CHAT_API_URL = "/api/chat"; // e.g. "https://yourapp.com/api/chat"

// === Auth (optional, for cross-device sync) ===
// The app works fully anonymously by default — no login wall, so someone in crisis gets in
// instantly. Signing in is optional and only used to sync a subscription across devices.
// Leave these blank to keep auth disabled.
const SUPABASE_URL = ""; // e.g. "https://xxxx.supabase.co"
const SUPABASE_ANON_KEY = ""; // your Supabase anon/public key

// A stable per-user ID. For real cross-device / cross-platform sync, replace this with the
// user ID from your auth system (Firebase/Supabase/etc.) so web and mobile share entitlements.
function getAppUserId() {
  try {
    let id = localStorage.getItem("yna_uid");
    if (!id) {
      id = "ynauser_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      localStorage.setItem("yna_uid", id);
    }
    return id;
  } catch {
    return undefined;
  }
}

function useLS(key, def) {
  const [v, sv] = useState(() => {
    try {
      const s = localStorage.getItem(key);
      return s ? JSON.parse(s) : def;
    } catch {
      return def;
    }
  });
  const set = (x) => {
    sv(x);
    try {
      localStorage.setItem(key, JSON.stringify(x));
    } catch {}
  };
  return [v, set];
}

function GT({ children }) {
  return (
    <span style={{ background: G, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
      {children}
    </span>
  );
}

function Card({ children, style, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: C.card,
        border: `1px solid ${C.border}`,
        borderRadius: 16,
        padding: 20,
        backdropFilter: "blur(12px)",
        cursor: onClick ? "pointer" : "default",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// Top bar with a back button — fixes the Android "no way back" problem.
function TopBar({ title, onBack, premium }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "20px 20px 4px" }}>
      <button
        onClick={onBack}
        aria-label="Back"
        style={{
          background: C.card,
          border: `1px solid ${C.border}`,
          borderRadius: 12,
          width: 40,
          height: 40,
          color: C.text,
          fontSize: 20,
          cursor: "pointer",
          flexShrink: 0,
        }}
      >
        ‹
      </button>
      <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: C.text, flex: 1 }}>{title}</h2>
      {premium && (
        <span style={{ fontSize: 11, fontWeight: 700, color: C.gold, border: `1px solid ${C.gold}55`, borderRadius: 20, padding: "4px 10px" }}>
          👑 PREMIUM
        </span>
      )}
    </div>
  );
}

// Soft lock shown in place of a premium feature for free users.
function PremiumLock({ feature, blurb, goPaywall }) {
  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <Card style={{ textAlign: "center", padding: "36px 24px" }}>
        <div style={{ fontSize: 40, marginBottom: 10 }}>🔒</div>
        <div style={{ fontSize: 18, fontWeight: 800, color: C.text }}>
          {feature} is <GT>Premium</GT>
        </div>
        <p style={{ color: C.muted, fontSize: 14, marginTop: 8 }}>{blurb}</p>
        <button
          onClick={goPaywall}
          style={{ marginTop: 18, width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 700, cursor: "pointer" }}
        >
          Unlock Premium
        </button>
      </Card>
    </div>
  );
}

function Home({ nav, stage, checkins, premium, tbResult }) {
  const s = HEAL_STAGES[(stage || 1) - 1];
  const aff = AFFIRMATIONS[Math.floor(Math.random() * 5)]; // free pool
  const tiles = [
    { id: "journal", emoji: "📓", label: "Journal", locked: !premium },
    { id: "learn", emoji: "📚", label: "Learn", locked: false },
    { id: "affirm", emoji: "✨", label: "Affirmations", locked: false },
    { id: "companion", emoji: "💜", label: "Recovery Coach", locked: !premium },
  ];
  return (
    <div style={{ padding: "0 20px 100px" }}>
      <div style={{ textAlign: "center", padding: "36px 0 24px" }}>
        <h1 style={{ margin: 0, fontSize: 30, fontWeight: 800, color: C.text, lineHeight: 1.2 }}>
          You're Not
          <br />
          <GT>Alone</GT>
        </h1>
        <p style={{ color: C.muted, fontSize: 13, marginTop: 6 }}>Healing from toxic relationships</p>
        {premium && (
          <div style={{ marginTop: 8, fontSize: 11, fontWeight: 700, color: C.gold }}>👑 You're Not Alone Premium</div>
        )}
      </div>

      <Card onClick={() => nav("crisis")} style={{ background: "rgba(239,68,68,0.14)", marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ fontSize: 22 }}>🆘</div>
          <div>
            <div style={{ fontWeight: 700, color: C.text, fontSize: 15 }}>Crisis Resources</div>
            <div style={{ color: C.muted, fontSize: 12 }}>Help right now — always free</div>
          </div>
        </div>
      </Card>

      <Card style={{ background: "rgba(232,121,160,0.15)", marginBottom: 14, textAlign: "center" }}>
        <div style={{ fontSize: 20, marginBottom: 6 }}>{aff.emoji}</div>
        <p style={{ color: C.text, fontSize: 15, fontStyle: "italic", margin: 0 }}>"{aff.text}"</p>
      </Card>

      <Card onClick={() => nav("stages")} style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 3 }}>
              Your Healing Stage {premium ? "" : "🔒"}
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>
              {premium ? `${s.emoji} ${s.label}` : "Track where you are"}
            </div>
          </div>
        </div>
      </Card>

      <Card onClick={() => nav("assessment")} style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 3 }}>Trauma Bond Check · free</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>
              {tbResult ? `Last score ${tbResult.total}/80` : "Take the assessment"}
            </div>
          </div>
          <div style={{ fontSize: 22 }}>🧭</div>
        </div>
      </Card>

      <Card onClick={() => nav("detector")} style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 3 }}>Red Flag Detector · free</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>Check a message</div>
          </div>
          <div style={{ fontSize: 22 }}>🚩</div>
        </div>
      </Card>

      <Card onClick={() => nav("nocontact")} style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 3 }}>No Contact Toolkit {premium ? "" : "🔒"}</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>
              {premium ? `🔥 ${ncDaysSince(ncStoredStart())} days no contact` : "Stay strong, day by day"}
            </div>
          </div>
          <div style={{ fontSize: 22 }}>🛡️</div>
        </div>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {tiles.map((n) => (
          <Card key={n.id} onClick={() => nav(n.id)} style={{ textAlign: "center", position: "relative" }}>
            {n.locked && <span style={{ position: "absolute", top: 10, right: 12, fontSize: 13 }}>🔒</span>}
            <div style={{ fontSize: 26, marginBottom: 5 }}>{n.emoji}</div>
            <div style={{ fontWeight: 700, color: C.text, fontSize: 14 }}>{n.label}</div>
          </Card>
        ))}
      </div>

      {premium && (
        <Card style={{ textAlign: "center", marginTop: 14 }}>
          <div style={{ fontSize: 26 }}>🔥</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: C.text }}>{checkins.length}</div>
          <div style={{ color: C.muted, fontSize: 11 }}>days showing up</div>
        </Card>
      )}

      {!premium && (
        <Card onClick={() => nav("paywall")} style={{ marginTop: 14, textAlign: "center", border: `1px solid ${C.gold}44` }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.text }}>👑 Unlock the full journey</div>
          <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>Companion, journal, urge surfing & more</div>
        </Card>
      )}

      <div onClick={() => nav("account")} style={{ textAlign: "center", marginTop: 16, color: C.muted, fontSize: 12, cursor: "pointer" }}>
        Account &amp; sync
      </div>
    </div>
  );
}

function Crisis() {
  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <p style={{ color: C.muted, fontSize: 13, marginBottom: 14 }}>
        If you're in immediate danger, call your local emergency number. You deserve support right now.
      </p>
      {[
        { name: "Emergency", note: "Immediate danger", num: "999 (UK) / 911 (US)" },
        { name: "Samaritans (UK)", note: "Free, 24/7, any kind of distress", num: "116 123" },
        { name: "National DV Helpline (UK)", note: "Refuge, 24/7", num: "0808 2000 247" },
        { name: "988 Lifeline (US)", note: "Suicide & crisis, 24/7", num: "988" },
      ].map((r, i) => (
        <Card key={i} style={{ marginBottom: 10 }}>
          <div style={{ fontWeight: 700, color: C.text, fontSize: 15 }}>{r.name}</div>
          <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>{r.note}</div>
          <div style={{ color: C.lav, fontSize: 15, marginTop: 6, fontWeight: 700 }}>{r.num}</div>
        </Card>
      ))}
      <p style={{ color: C.muted, fontSize: 11, marginTop: 12 }}>
        Replace these with verified, up-to-date numbers for your launch regions before publishing.
      </p>
    </div>
  );
}

// Education Hub lessons — free. Plain-language explanations of the core patterns.
const LESSONS = [
  {
    id: "trauma-bond",
    title: "Trauma Bonds",
    emoji: "🔗",
    color: C.purple,
    short: "Why an unhealthy relationship can feel impossible to leave.",
    detail:
      "A trauma bond is a strong emotional attachment formed through repeated cycles of affection and mistreatment. The unpredictable swing between warmth and hurt — sometimes called intermittent reinforcement — keeps you hoping the 'good' version of the person will return, which can make an unhealthy relationship very difficult to leave. Feeling bonded this way isn't weakness or a flaw in you; it's a normal response to an abnormal pattern, and naming it is the first step to loosening its grip.",
  },
  {
    id: "gaslighting",
    title: "Gaslighting",
    emoji: "💡",
    color: C.gold,
    short: "Manipulation that makes you doubt your own reality.",
    detail:
      "Gaslighting is a manipulation tactic that slowly causes you to question your own reality, memory, or judgement. It often sounds like \"that never happened,\" \"you're overreacting,\" or \"you're too sensitive.\" Over time it can leave you apologising for things you didn't do and trusting someone else's version of events over your own. A useful anchor: your feelings and memories are valid data, even when someone insists they aren't.",
  },
  {
    id: "love-bombing",
    title: "Love Bombing",
    emoji: "💣",
    color: C.pink,
    short: "Intense early affection used to build fast dependency.",
    detail:
      "Love bombing is a wave of excessive affection, gifts, attention, and fast commitment — often very early on — used to create emotional dependency. It can feel like the most intense connection of your life. The warning sign isn't affection itself, but the speed and pressure, and what tends to follow: once you're attached, the same intensity can flip into criticism or withdrawal. Healthy love can be strong, but it doesn't rush you or demand proof.",
  },
  {
    id: "healthy",
    title: "Healthy Relationships",
    emoji: "🌿",
    color: "#10B981",
    short: "What safe, steady love actually looks like.",
    detail:
      "Healthy relationships are built on trust, honest communication, respect, clear boundaries, and consistency. You can disagree and still feel safe. Your 'no' is accepted without punishment, your other relationships are welcomed rather than resented, and you don't have to earn basic kindness. It often feels calmer than what a trauma bond trains you to expect — and that calm is a sign of safety, not the absence of love.",
  },
];

// Learn — free Education Hub: topic lessons + the 5 healing stages. Tap to expand.
function Learn({ nav }) {
  const [open, setOpen] = useState(null);
  const [read, setRead] = useLS("yna_lessons_read", []);
  const toggle = (id) => {
    setOpen(open === id ? null : id);
    if (open !== id && !read.includes(id)) setRead([...read, id]);
  };

  const ExpandCard = ({ item, isOpen }) => (
    <Card
      onClick={() => toggle(item.id)}
      style={{ marginBottom: 12, border: isOpen ? `1px solid ${item.color}` : `1px solid ${C.border}` }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 42, height: 42, borderRadius: 12, background: item.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>
          {item.emoji}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, color: C.text, fontSize: 16 }}>{item.label}</div>
          {!isOpen && <div style={{ color: C.muted, fontSize: 13, marginTop: 4 }}>{item.short}</div>}
        </div>
        <div style={{ color: C.muted, fontSize: 16, transition: "transform .2s", transform: isOpen ? "rotate(180deg)" : "none" }}>⌄</div>
      </div>
      {isOpen && (
        <p style={{ color: C.text, fontSize: 14, lineHeight: 1.55, marginTop: 14, marginBottom: 0 }}>{item.detail}</p>
      )}
    </Card>
  );

  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <div style={{ fontSize: 13, color: C.muted, margin: "0 2px 10px" }}>Topics</div>
      {LESSONS.map((l) => (
        <ExpandCard key={l.id} item={{ ...l, label: l.title }} isOpen={open === l.id} />
      ))}

      <button
        onClick={() => nav && nav("companion")}
        style={{ width: "100%", margin: "2px 0 8px", padding: 13, borderRadius: 12, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 14, fontWeight: 700, cursor: "pointer" }}
      >
        💜 Go deeper with your Recovery Coach
      </button>

      <div style={{ fontSize: 13, color: C.muted, margin: "18px 2px 10px" }}>The 5 healing stages</div>
      <p style={{ color: C.muted, fontSize: 13, marginTop: 0, marginBottom: 12 }}>
        Tap a stage to read what it really feels like.
      </p>
      {HEAL_STAGES.map((s) => (
        <ExpandCard key={s.id} item={{ ...s, id: `stage-${s.id}`, label: s.label }} isOpen={open === `stage-${s.id}`} />
      ))}
    </div>
  );
}

// Stage tracker — premium (setting/tracking your current stage).
function Stages({ stage, setStage }) {
  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <p style={{ color: C.muted, fontSize: 13, marginBottom: 12 }}>Where are you right now?</p>
      {HEAL_STAGES.map((s) => {
        const on = stage === s.id;
        return (
          <Card key={s.id} onClick={() => setStage(s.id)} style={{ marginBottom: 12, border: on ? `1px solid ${s.color}` : `1px solid ${C.border}` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ fontSize: 26 }}>{s.emoji}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: C.text, fontSize: 15 }}>{s.label}</div>
              </div>
              {on && <div style={{ fontSize: 18 }}>✓</div>}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

// Journal — premium (write + full history).
function Journal({ entries, onSave }) {
  const [text, setText] = useState("");
  const [saved, setSaved] = useState(false);
  const save = () => {
    if (!text.trim()) return;
    onSave({ date: new Date().toISOString(), text: text.trim() });
    setText("");
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Write here..."
        style={{ width: "100%", minHeight: 150, background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, color: C.text, fontSize: 15, padding: 16, marginBottom: 16, boxSizing: "border-box", fontFamily: "inherit" }}
      />
      <button onClick={save} style={{ width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 700, cursor: "pointer" }}>
        {saved ? "✓ Saved" : "Save"}
      </button>
      <div style={{ marginTop: 20 }}>
        {entries.slice().reverse().map((e, i) => (
          <Card key={i} style={{ marginBottom: 10 }}>
            <div style={{ color: C.muted, fontSize: 11, marginBottom: 6 }}>{new Date(e.date).toLocaleDateString()}</div>
            <p style={{ color: C.text, fontSize: 14, margin: 0 }}>{e.text}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}

// Affirmations — free users get 5 rotating, no save/filter; premium gets the full library.
function Affirm({ premium, goPaywall }) {
  const [favs, setFavs] = useLS("yna_favs", []);
  const [cat, setCat] = useState("All");
  const tog = (t) => setFavs(favs.includes(t) ? favs.filter((f) => f !== t) : [...favs, t]);

  const cats = ["All", ...Array.from(new Set(AFFIRMATIONS.map((a) => a.cat)))];
  const list = premium ? AFFIRMATIONS : AFFIRMATIONS.filter((a) => a.free);
  const shown = premium && cat !== "All" ? list.filter((a) => a.cat === cat) : list;

  return (
    <div style={{ padding: "8px 20px 100px" }}>
      {premium && (
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 12, marginBottom: 4 }}>
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              style={{ flexShrink: 0, padding: "6px 14px", borderRadius: 20, border: `1px solid ${C.border}`, background: cat === c ? G : C.card, color: C.text, fontSize: 13, fontWeight: 600, cursor: "pointer" }}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      {shown.map((a, i) => (
        <Card key={i} style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            <div style={{ fontSize: 22 }}>{a.emoji}</div>
            <div style={{ flex: 1 }}>
              <p style={{ color: C.text, fontSize: 15, margin: 0, fontStyle: "italic" }}>"{a.text}"</p>
            </div>
            {premium && (
              <button onClick={() => tog(a.text)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 22, color: favs.includes(a.text) ? C.pink : C.muted }}>
                {favs.includes(a.text) ? "♥" : "♡"}
              </button>
            )}
          </div>
        </Card>
      ))}

      {!premium && (
        <Card onClick={goPaywall} style={{ textAlign: "center", border: `1px solid ${C.gold}44` }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.text }}>🔒 Unlock all 25 affirmations</div>
          <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>Save favourites & filter by category with Premium</div>
        </Card>
      )}
    </div>
  );
}

// Shared transport to your server proxy (api/chat.js). The proxy adds the API key
// server-side and talks to Anthropic, so the key is never exposed in the client.
async function chatProxy({ system, messages, authToken }) {
  const headers = { "Content-Type": "application/json" };
  if (authToken) headers.Authorization = `Bearer ${authToken}`;
  const res = await fetch(CHAT_API_URL, {
    method: "POST",
    headers,
    body: JSON.stringify({ system, messages: messages.map((m) => ({ role: m.role, content: m.content })) }),
  });
  if (!res.ok) throw new Error(`Proxy ${res.status}`);
  const data = await res.json();
  if (!data.reply) throw new Error("empty reply");
  return data.reply;
}

// === AI Recovery Coach ===
// Shared base prompt + four selectable modes. The base keeps the coach warm, Socratic, and
// safe; each mode steers the focus. Sent to chatProxy() exactly like before, so no backend
// change is needed beyond what the Companion already used.
const COACH_BASE =
  "You are the AI Recovery Coach inside 'You're Not Alone', an app for people healing from toxic, narcissistic, or emotionally abusive relationships. Be warm, validating, and non-judgmental. Favour gentle Socratic questions that help the person examine the evidence for a thought rather than telling them what to do. When relevant, name manipulation patterns plainly (push-pull / intermittent reinforcement, gaslighting, blame-shifting, love bombing, trauma bonding) but never diagnose the person or their partner, and never label anyone as a narcissist with certainty. Keep replies short and kind — usually 2 to 4 sentences, often ending with one reflective question. Never tell them to leave or to stay; support their own clarity and autonomy. You are not a therapist and you do not give medical advice. If they mention being in physical danger, abuse escalating, or any thought of harming themselves, gently and immediately encourage them to open the Crisis Resources in the app or contact local emergency services.";

const COACH_MODES = [
  {
    id: "recovery",
    label: "Recovery",
    emoji: "🌱",
    blurb: "Daily support",
    opener: "I'm right here with you today. How are you feeling, and what's on your mind?",
    prompts: ["He hasn't messaged me in 3 days", "I miss them today", "Why do I keep defending them?"],
    system:
      "MODE: RECOVERY (daily support). Focus on getting through today with self-compassion, small grounding steps, and slowly rebuilding identity and self-worth. Gently separate the person's worth from the other person's behaviour.",
  },
  {
    id: "crisis",
    label: "Crisis",
    emoji: "🆘",
    blurb: "Urges to contact",
    opener: "The urge to reach out can feel enormous — and it does pass, usually faster than it promises to. Let's ride this wave together. What's happening right now?",
    prompts: ["I want to text my ex", "I keep checking their socials", "They just messaged me"],
    system:
      "MODE: CRISIS (contact urges). The person feels a strong urge to contact, check on, or respond to an ex. Help them surf the urge: validate it, remind them urges peak and pass, explore what they're really hoping to get, and support their no-contact intention without shaming a slip. This 'crisis' means emotional urges — if they describe physical danger or self-harm, point them to Crisis Resources immediately.",
  },
  {
    id: "education",
    label: "Education",
    emoji: "📚",
    blurb: "Learn the patterns",
    opener: "Understanding the patterns takes a lot of their power away. What would you like to understand?",
    prompts: ["He says everything is my fault", "What is a trauma bond?", "What is push-pull?"],
    system:
      "MODE: EDUCATION (learning patterns). Explain abuse and manipulation patterns clearly and accessibly, with brief concrete examples. Tie concepts back to what the person shares and check their understanding. Stay educational, not diagnostic.",
  },
  {
    id: "reflection",
    label: "Reflection",
    emoji: "📓",
    blurb: "Guided journaling",
    opener: "Let's slow down and reflect. I'll offer a gentle question or two — answer however feels honest. Ready?",
    prompts: ["Help me journal tonight", "I don't know what I'm feeling", "What should I reflect on?"],
    system:
      "MODE: REFLECTION (guided journaling). Act as a guided-journaling companion. Ask one open, reflective question at a time, leave space, and deepen gently based on their answer. At natural moments, mention they can save a reflection to their Journal in the app.",
  },
];

// AI Recovery Coach — premium. Mode-based coaching over the same server proxy.
function Companion({ stage, authToken, nav }) {
  const [modeId, setModeId] = useState("recovery");
  const mode = COACH_MODES.find((m) => m.id === modeId) || COACH_MODES[0];
  const [msgs, setMsgs] = useState([{ role: "assistant", content: COACH_MODES[0].opener }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const s = HEAL_STAGES[(stage || 1) - 1];

  const pickMode = (id) => {
    const m = COACH_MODES.find((x) => x.id === id) || COACH_MODES[0];
    setModeId(id);
    setMsgs([{ role: "assistant", content: m.opener }]);
    setInput("");
  };

  const sendText = async (override) => {
    const msg = (override != null ? override : input).trim();
    if (!msg || loading) return;
    setInput("");
    const updated = [...msgs, { role: "user", content: msg }];
    setMsgs(updated);
    setLoading(true);
    try {
      const system = `${COACH_BASE}\n\n${mode.system}\n\nThe person is currently in the "${s.label}" stage of healing.`;
      const reply = await chatProxy({ system, messages: updated, authToken });
      setMsgs([...updated, { role: "assistant", content: reply }]);
    } catch {
      setMsgs([...updated, { role: "assistant", content: "Sorry — I had trouble responding just then. Please try again in a moment. 💜" }]);
    } finally {
      setLoading(false);
    }
  };

  const showPrompts = msgs.length <= 1 && !loading;

  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 10 }}>
        {COACH_MODES.map((m) => {
          const on = m.id === modeId;
          return (
            <button
              key={m.id}
              onClick={() => pickMode(m.id)}
              style={{ flexShrink: 0, padding: "7px 13px", borderRadius: 20, border: on ? "1px solid transparent" : `1px solid ${C.border}`, background: on ? G : C.card, color: C.text, fontSize: 13, fontWeight: 700, cursor: "pointer" }}
            >
              {m.emoji} {m.label}
            </button>
          );
        })}
      </div>
      <div style={{ color: C.muted, fontSize: 12, margin: "2px 2px 12px" }}>{mode.emoji} {mode.label} mode · {mode.blurb}</div>

      {mode.id === "crisis" && (
        <Card onClick={() => nav && nav("crisis")} style={{ background: "rgba(239,68,68,0.14)", marginBottom: 12 }}>
          <div style={{ fontSize: 13, color: C.text, fontWeight: 700 }}>In real danger or thinking of harming yourself? Tap for Crisis Resources →</div>
        </Card>
      )}

      <div style={{ marginBottom: 12 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: 10 }}>
            <div style={{ maxWidth: "82%", padding: "10px 14px", borderRadius: 12, background: m.role === "user" ? G : C.card, color: C.text, fontSize: 14, lineHeight: 1.45 }}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", justifyContent: "flex-start", marginBottom: 10 }}>
            <div style={{ padding: "10px 14px", borderRadius: 12, background: C.card, color: C.muted, fontSize: 14 }}>…</div>
          </div>
        )}
      </div>

      {showPrompts && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
          {mode.prompts.map((p, i) => (
            <button key={i} onClick={() => sendText(p)} style={{ padding: "8px 12px", borderRadius: 14, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 13, cursor: "pointer", textAlign: "left" }}>
              {p}
            </button>
          ))}
        </div>
      )}

      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && sendText()}
        placeholder="Talk to your coach..."
        style={{ width: "100%", padding: 12, borderRadius: 12, background: C.card, border: `1px solid ${C.border}`, color: C.text, fontSize: 14, marginBottom: 10, boxSizing: "border-box" }}
      />
      <button onClick={() => sendText()} disabled={loading} style={{ width: "100%", padding: 12, borderRadius: 12, border: "none", background: G, color: C.text, fontWeight: 700, cursor: loading ? "default" : "pointer", opacity: loading ? 0.6 : 1 }}>
        {loading ? "Sending…" : "Send"}
      </button>
      <p style={{ color: C.muted, fontSize: 11, lineHeight: 1.5, marginTop: 12, textAlign: "center" }}>
        Your coach is supportive AI, not a therapist, and can be wrong. For emergencies use Crisis Resources.
      </p>
    </div>
  );
}

// Paywall / pricing — uses RevenueCat Web Billing when configured, else a local unlock for testing.
function Paywall({ onUnlock, rc, offerings }) {
  const [plan, setPlan] = useState("yearly");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  // Map our plan ids to RevenueCat packages (configured in your dashboard Offering).
  const pkgFor = { monthly: offerings?.monthly, yearly: offerings?.annual, lifetime: offerings?.lifetime };

  const startCheckout = async () => {
    setErr("");
    const pkg = pkgFor[plan];
    if (rc && pkg) {
      setBusy(true);
      try {
        const { customerInfo } = await rc.purchase({ rcPackage: pkg });
        if (PREMIUM_ENTITLEMENT in customerInfo.entitlements.active) {
          onUnlock();
        } else {
          setErr("Purchase didn't activate Premium. Please contact support.");
        }
      } catch (e) {
        // User cancelled or payment failed — stay on the paywall.
        setErr("Checkout didn't complete. You can try again.");
      } finally {
        setBusy(false);
      }
    } else if (!REVENUECAT_WEB_KEY) {
      // FIX #1 (free-premium leak): only unlock locally when NO billing key is configured.
      // Local testing mode — lets you click through gated screens before billing is live.
      onUnlock();
    } else {
      // Billing IS configured but the package didn't resolve. This happens when offerings
      // are still loading, or the dashboard Offering isn't using the standard
      // $rc_monthly / $rc_annual / $rc_lifetime package identifiers the accessors rely on.
      // Do NOT unlock for free here — surface an error so a misconfiguration can't give away
      // Premium.
      setErr("Plans are still loading — please try again in a moment.");
    }
  };
  const plans = [
    { id: "monthly", label: "Monthly", price: PRICING.monthly, sub: "per month" },
    { id: "yearly", label: "Yearly", price: PRICING.yearly, sub: "per year · best value" },
    { id: "lifetime", label: "Lifetime", price: PRICING.lifetime, sub: "one-time" },
  ];
  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <div style={{ textAlign: "center", padding: "12px 0 20px" }}>
        <div style={{ fontSize: 40, marginBottom: 8 }}>👑</div>
        <h2 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: C.text }}>
          <GT>You're Not Alone</GT> Premium
        </h2>
        <p style={{ color: C.muted, fontSize: 14, marginTop: 8 }}>Unlimited support as you go deeper.</p>
      </div>

      <Card style={{ marginBottom: 16 }}>
        {[
          "AI Recovery Coach — unlimited chat, 4 modes",
          "No Contact Toolkit — streak, urge SOS & triggers",
          "Red Flag pattern scanner + trauma-bond detection",
          "Full journal with complete history",
          "Urge surfing — full guided sessions",
          "Full affirmations library (save & filter)",
          "Check-in history + streak tracking",
          "Healing stage tracker",
        ].map((f, i, arr) => (
          // FIX #2 (margin): remove the bottom gap on the LAST item, not a hardcoded index.
          <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: i === arr.length - 1 ? 0 : 10 }}>
            <span style={{ color: C.gold }}>✓</span>
            <span style={{ color: C.text, fontSize: 14 }}>{f}</span>
          </div>
        ))}
      </Card>

      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
        {plans.map((p) => {
          const on = plan === p.id;
          return (
            <Card key={p.id} onClick={() => setPlan(p.id)} style={{ border: on ? `1px solid ${C.gold}` : `1px solid ${C.border}`, padding: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontWeight: 700, color: C.text, fontSize: 15 }}>{p.label}</div>
                  <div style={{ color: C.muted, fontSize: 12 }}>{p.sub}</div>
                </div>
                <div style={{ fontSize: 18, fontWeight: 800, color: C.text }}>{p.price}</div>
              </div>
            </Card>
          );
        })}
      </div>

      <button onClick={startCheckout} disabled={busy} style={{ width: "100%", padding: 16, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 800, cursor: busy ? "default" : "pointer", opacity: busy ? 0.6 : 1 }}>
        {busy ? "Opening checkout…" : `Start with ${plans.find((p) => p.id === plan).label}`}
      </button>
      {err && <p style={{ color: C.pink, fontSize: 12, textAlign: "center", marginTop: 10 }}>{err}</p>}
      <p style={{ color: C.muted, fontSize: 11, textAlign: "center", marginTop: 12 }}>
        Crisis resources and the Learn section are always free. Cancel anytime.
      </p>
    </div>
  );
}

// Account — optional email sign-in (magic link) so a subscription can sync across devices.
function Account({ supabase, session, onSignedOut }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  if (!supabase) {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Card>
          <p style={{ color: C.text, fontSize: 14, margin: 0 }}>
            Accounts aren't set up yet. The app works fully without one — your data stays on this device.
          </p>
        </Card>
      </div>
    );
  }

  if (session) {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Card style={{ marginBottom: 14 }}>
          <div style={{ color: C.muted, fontSize: 12 }}>Signed in as</div>
          <div style={{ color: C.text, fontSize: 15, fontWeight: 700, marginTop: 4 }}>{session.user?.email}</div>
          <div style={{ color: C.muted, fontSize: 12, marginTop: 8 }}>Your subscription will follow you across devices.</div>
        </Card>
        <button
          onClick={async () => {
            await supabase.auth.signOut();
            onSignedOut();
          }}
          style={{ width: "100%", padding: 14, borderRadius: 14, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 15, fontWeight: 700, cursor: "pointer" }}
        >
          Sign out
        </button>
      </div>
    );
  }

  const sendLink = async () => {
    if (!email.trim() || busy) return;
    setBusy(true);
    setErr("");
    try {
      const { error } = await supabase.auth.signInWithOtp({ email: email.trim() });
      if (error) throw error;
      setSent(true);
    } catch (e) {
      setErr("Couldn't send the link. Check the address and try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <p style={{ color: C.muted, fontSize: 13, marginBottom: 14 }}>
        Optional. Sign in to keep your subscription when you change phones. We'll email you a link — no password.
      </p>
      {sent ? (
        <Card>
          <p style={{ color: C.text, fontSize: 14, margin: 0 }}>Check your email for a sign-in link. 💜</p>
        </Card>
      ) : (
        <>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            inputMode="email"
            style={{ width: "100%", padding: 12, borderRadius: 12, background: C.card, border: `1px solid ${C.border}`, color: C.text, fontSize: 14, marginBottom: 10, boxSizing: "border-box" }}
          />
          <button onClick={sendLink} disabled={busy} style={{ width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 700, cursor: busy ? "default" : "pointer", opacity: busy ? 0.6 : 1 }}>
            {busy ? "Sending…" : "Email me a sign-in link"}
          </button>
          {err && <p style={{ color: C.pink, fontSize: 12, textAlign: "center", marginTop: 10 }}>{err}</p>}
        </>
      )}
    </div>
  );
}

// Trauma Bond Assessment — free. Questionnaire → results with overall band, five
// sub-scores, personalised insights and a safety flag linking to Crisis resources.
function Assessment({ nav, onSave }) {
  const [answers, setAnswers] = useState(() => Array(TB_QUESTIONS.length).fill(null));
  const [showResult, setShowResult] = useState(false);

  const answered = answers.filter((a) => a !== null).length;
  const allAnswered = answered === TB_QUESTIONS.length;

  const setAns = (qi, v) => {
    const next = answers.slice();
    next[qi] = v;
    setAnswers(next);
  };

  const compute = () => {
    const total = answers.reduce((s, a) => s + (a || 0), 0);
    const subs = TB_SUBSCALES.map((sc) => {
      const raw = sc.q.reduce((s, qi) => s + (answers[qi] || 0), 0);
      const maxRaw = sc.q.length * 4;
      return { ...sc, raw, maxRaw, pct: Math.round((raw / maxRaw) * 100) };
    });
    // Flag if overall is very high, OR "Almost always" on all three "can't leave" items
    // (Q9, Q17, Q19 → indices 8, 16, 18).
    const a = answers;
    const flag = total >= 70 || (a[8] === 4 && a[16] === 4 && a[18] === 4);
    return { total, subs, flag, date: new Date().toISOString() };
  };

  const submit = () => {
    if (!allAnswered) return;
    const r = compute();
    onSave({ date: r.date, total: r.total });
    setShowResult(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const restart = () => {
    setAnswers(Array(TB_QUESTIONS.length).fill(null));
    setShowResult(false);
  };

  // ---------- Results ----------
  if (showResult) {
    const r = compute();
    const band = tbBand(r.total);
    const insights = r.subs.filter((s) => s.pct >= 40);
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Card style={{ textAlign: "center", marginBottom: 14, border: `1px solid ${band.color}55` }}>
          <div style={{ fontSize: 12, color: C.muted }}>Your overall score</div>
          <div style={{ fontSize: 40, fontWeight: 800, color: C.text, lineHeight: 1.1, marginTop: 4 }}>
            {r.total}
            <span style={{ fontSize: 18, color: C.muted, fontWeight: 700 }}> / 80</span>
          </div>
          <div style={{ marginTop: 10, height: 8, borderRadius: 8, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
            <div style={{ width: `${(r.total / 80) * 100}%`, height: "100%", background: band.color }} />
          </div>
          <div style={{ fontSize: 17, fontWeight: 800, color: band.color, marginTop: 12 }}>{band.label}</div>
          <p style={{ color: C.text, fontSize: 14, lineHeight: 1.5, marginTop: 6, marginBottom: 0 }}>{band.blurb}</p>
        </Card>

        {r.flag && (
          <Card style={{ background: "rgba(239,68,68,0.16)", border: "1px solid rgba(239,68,68,0.4)", marginBottom: 14 }}>
            <div style={{ fontWeight: 800, color: C.text, fontSize: 15, marginBottom: 6 }}>💗 A note for you</div>
            <p style={{ color: C.text, fontSize: 14, lineHeight: 1.55, margin: 0 }}>
              Your responses suggest significant difficulty leaving a harmful relationship. Consider reaching out to a
              trusted friend, counsellor, therapist, or support service for additional support.
            </p>
            <button
              onClick={() => nav("crisis")}
              style={{ marginTop: 14, width: "100%", padding: 13, borderRadius: 12, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 700, cursor: "pointer" }}
            >
              See support resources
            </button>
          </Card>
        )}

        <div style={{ fontSize: 13, color: C.muted, margin: "4px 2px 10px" }}>Your patterns, broken down</div>
        {r.subs.map((s) => (
          <Card key={s.key} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
              <span style={{ fontWeight: 700, color: C.text, fontSize: 14 }}>{s.label}</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: s.color }}>{tbSubBand(s.pct)} · {s.raw}/{s.maxRaw}</span>
            </div>
            <div style={{ height: 8, borderRadius: 8, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
              <div style={{ width: `${s.pct}%`, height: "100%", background: s.color }} />
            </div>
          </Card>
        ))}

        {insights.length > 0 && (
          <>
            <div style={{ fontSize: 13, color: C.muted, margin: "16px 2px 10px" }}>Recovery insights</div>
            {insights.map((s) => (
              <Card key={s.key} style={{ marginBottom: 10, borderLeft: `3px solid ${s.color}` }}>
                <div style={{ fontWeight: 700, color: C.text, fontSize: 14, marginBottom: 4 }}>{s.label}</div>
                <p style={{ color: C.text, fontSize: 14, lineHeight: 1.55, margin: 0 }}>{s.insight}</p>
              </Card>
            ))}
          </>
        )}

        <Card style={{ marginTop: 14, background: "rgba(232,121,160,0.12)" }}>
          <p style={{ color: C.muted, fontSize: 12, lineHeight: 1.5, margin: 0 }}>
            This is an educational self-reflection tool, not a diagnosis. Trauma bonding is a recognised pattern, but only
            you and a qualified professional can understand your full situation. Be gentle with yourself. 💜
          </p>
        </Card>

        <button onClick={restart} style={{ marginTop: 16, width: "100%", padding: 14, borderRadius: 14, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 15, fontWeight: 700, cursor: "pointer" }}>
          Take it again
        </button>
      </div>
    );
  }

  // ---------- Questionnaire ----------
  return (
    <div style={{ padding: "8px 20px 110px" }}>
      <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.55, marginTop: 0, marginBottom: 14 }}>
        Answer each question based on your relationship over the past 12 months. There are no right answers — this is just
        a mirror to help you see clearly.
      </p>

      {TB_QUESTIONS.map((qt, qi) => (
        <Card key={qi} style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            <span style={{ color: C.lav, fontWeight: 800, fontSize: 14, flexShrink: 0 }}>{qi + 1}.</span>
            <span style={{ color: C.text, fontSize: 14, lineHeight: 1.45 }}>{qt}</span>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {TB_SCALE.map((opt) => {
              const on = answers[qi] === opt.v;
              return (
                <button
                  key={opt.v}
                  onClick={() => setAns(qi, opt.v)}
                  style={{ flex: "1 1 auto", padding: "8px 6px", borderRadius: 10, border: on ? "1px solid transparent" : `1px solid ${C.border}`, background: on ? G : "transparent", color: C.text, fontSize: 12, fontWeight: on ? 700 : 500, cursor: "pointer", opacity: on ? 1 : 0.75 }}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </Card>
      ))}

      <button
        onClick={submit}
        disabled={!allAnswered}
        style={{ width: "100%", padding: 16, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 800, cursor: allAnswered ? "pointer" : "default", opacity: allAnswered ? 1 : 0.45, marginTop: 4 }}
      >
        {allAnswered ? "See your results" : `Answer all 20 (${answered}/20)`}
      </button>
    </div>
  );
}

// Red Flag Detector — single-message analyzer (free) + multi-message Pattern Scanner (premium).
function Detector({ nav, premium, goPaywall, onSaveJournal }) {
  const [mode, setMode] = useState("single");
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);
  const [scan, setScan] = useState(null);
  const [saved, setSaved] = useState(false);

  const switchMode = (m) => {
    setMode(m);
    setText("");
    setResult(null);
    setScan(null);
    setSaved(false);
  };
  const analyze = () => {
    if (!text.trim()) return;
    setResult(rfAnalyze(text));
    setScan(null);
    setSaved(false);
  };
  const runScan = () => {
    if (!text.trim()) return;
    setScan(rfScan(text));
    setResult(null);
    setSaved(false);
  };
  const saveJournal = () => {
    if (!result) return;
    if (!premium) {
      goPaywall();
      return;
    }
    const band = rfBand(result.score);
    const flags = result.detected.map((d) => d.label).join(", ") || "no clear flags";
    const t = text.trim();
    onSaveJournal({
      date: new Date().toISOString(),
      text: `Red Flag check — ${result.score}/100 (${band.label}).\nPatterns: ${flags}.\n\n"${t.slice(0, 140)}${t.length > 140 ? "…" : ""}"`,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const coachLine = result && result.detected.length
    ? result.detected[0].coach
    : "Notice how this message lands in your body. Your gut is data too — if something feels off, that's worth listening to.";

  return (
    <div style={{ padding: "8px 20px 110px" }}>
      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        {[{ id: "single", label: "One message" }, { id: "pattern", label: "Pattern scan 👑" }].map((m) => (
          <button
            key={m.id}
            onClick={() => switchMode(m.id)}
            style={{ flex: 1, padding: "9px 6px", borderRadius: 12, border: mode === m.id ? "1px solid transparent" : `1px solid ${C.border}`, background: mode === m.id ? G : C.card, color: C.text, fontSize: 13, fontWeight: 700, cursor: "pointer" }}
          >
            {m.label}
          </button>
        ))}
      </div>

      {mode === "single" && (
        <>
          <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.55, marginTop: 0, marginBottom: 12 }}>
            Paste a message and I'll point out patterns it contains. This isn't a verdict on your relationship — just a
            mirror to help you notice things.
          </p>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={'Paste text here…  e.g. "If you loved me you wouldn\'t need anyone else."'}
            style={{ width: "100%", minHeight: 120, background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, color: C.text, fontSize: 15, padding: 16, marginBottom: 12, boxSizing: "border-box", fontFamily: "inherit" }}
          />
          <button onClick={analyze} disabled={!text.trim()} style={{ width: "100%", padding: 15, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 800, cursor: text.trim() ? "pointer" : "default", opacity: text.trim() ? 1 : 0.45 }}>
            Analyze message
          </button>

          {result && (() => {
            const band = rfBand(result.score);
            return (
              <div style={{ marginTop: 18 }}>
                <Card style={{ textAlign: "center", marginBottom: 14, border: `1px solid ${band.color}55` }}>
                  <div style={{ fontSize: 12, color: C.muted }}>Risk score</div>
                  <div style={{ fontSize: 40, fontWeight: 800, color: band.color, lineHeight: 1.1, marginTop: 2 }}>
                    {band.emoji} {result.score}
                    <span style={{ fontSize: 18, color: C.muted, fontWeight: 700 }}> / 100</span>
                  </div>
                  <div style={{ marginTop: 10, height: 8, borderRadius: 8, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                    <div style={{ width: `${result.score}%`, height: "100%", background: band.color }} />
                  </div>
                  <div style={{ fontSize: 16, fontWeight: 800, color: band.color, marginTop: 12 }}>{band.label}</div>
                </Card>

                <div style={{ fontSize: 13, color: C.muted, margin: "4px 2px 10px" }}>Detected patterns</div>
                {result.detected.length === 0 ? (
                  <Card style={{ marginBottom: 14, borderLeft: "3px solid #10B981" }}>
                    <div style={{ fontWeight: 700, color: C.text, fontSize: 14 }}>🟢 No clear red flags found</div>
                    <p style={{ color: C.muted, fontSize: 13, margin: "6px 0 0", lineHeight: 1.5 }}>
                      Nothing here matched the patterns I look for. That isn't a guarantee — trust your own sense of how it felt.
                    </p>
                  </Card>
                ) : (
                  result.detected.map((d) => (
                    <Card key={d.key} style={{ marginBottom: 10, borderLeft: `3px solid ${RF_TIER_COLOR[d.tier]}` }}>
                      <div style={{ fontWeight: 700, color: C.text, fontSize: 14 }}>🚩 {d.label}</div>
                      <p style={{ color: C.muted, fontSize: 13, margin: "5px 0 0", lineHeight: 1.5 }}>{d.blurb}</p>
                    </Card>
                  ))
                )}

                <Card style={{ marginTop: 4, marginBottom: 14 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.lav, marginBottom: 6 }}>Why this matters</div>
                  <p style={{ color: C.text, fontSize: 14, lineHeight: 1.55, margin: 0 }}>{band.why}</p>
                </Card>

                <Card style={{ marginBottom: 16, background: "rgba(232,121,160,0.12)" }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: C.pink, marginBottom: 6 }}>💜 Recovery Coach says</div>
                  <p style={{ color: C.text, fontSize: 14, lineHeight: 1.55, margin: 0, fontStyle: "italic" }}>"{coachLine}"</p>
                </Card>

                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={saveJournal} style={{ flex: 1, padding: 13, borderRadius: 12, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
                    {saved ? "✓ Saved" : premium ? "Save to Journal" : "Save to Journal 👑"}
                  </button>
                  <button onClick={() => nav("crisis")} style={{ flex: 1, padding: 13, borderRadius: 12, border: "none", background: G, color: C.text, fontSize: 14, fontWeight: 800, cursor: "pointer" }}>
                    Get support
                  </button>
                </div>

                <button onClick={() => nav("companion")} style={{ width: "100%", marginTop: 10, padding: 13, borderRadius: 12, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
                  💜 Talk this through with your Recovery Coach
                </button>

                <Card style={{ marginTop: 14 }}>
                  <p style={{ color: C.muted, fontSize: 12, lineHeight: 1.5, margin: 0 }}>
                    This spots common patterns in wording — it isn't proof of abuse or a diagnosis, and context matters. If
                    you're ever in danger, use Get support above. Trust yourself. 💜
                  </p>
                </Card>
              </div>
            );
          })()}
        </>
      )}

      {mode === "pattern" && !premium && (
        <Card style={{ textAlign: "center", padding: "32px 22px" }}>
          <div style={{ fontSize: 38, marginBottom: 8 }}>🔒</div>
          <div style={{ fontSize: 17, fontWeight: 800, color: C.text }}>
            The <GT>Pattern Scanner</GT> is Premium
          </div>
          <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.55, marginTop: 8 }}>
            Scan many messages at once to see how patterns build over time — and surface possible trauma-bond cycles that
            a single message can't show.
          </p>
          <button onClick={goPaywall} style={{ marginTop: 16, width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 700, cursor: "pointer" }}>
            Unlock Premium
          </button>
        </Card>
      )}

      {mode === "pattern" && premium && (
        <>
          <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.55, marginTop: 0, marginBottom: 12 }}>
            Paste several messages — one per line. The scanner looks for patterns across all of them, because a single
            message rarely tells the whole story.
          </p>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"One message per line, e.g.\nYou're my soulmate, I've never felt this way.\nWhy didn't you answer? Who are you with?\nI only ignored you because you upset me.\nIf you loved me you wouldn't need those friends."}
            style={{ width: "100%", minHeight: 160, background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, color: C.text, fontSize: 15, padding: 16, marginBottom: 12, boxSizing: "border-box", fontFamily: "inherit" }}
          />
          <button onClick={runScan} disabled={!text.trim()} style={{ width: "100%", padding: 15, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 16, fontWeight: 800, cursor: text.trim() ? "pointer" : "default", opacity: text.trim() ? 1 : 0.45 }}>
            Scan messages
          </button>

          {scan && (() => {
            const band = rfBand(scan.avg);
            return (
              <div style={{ marginTop: 18 }}>
                <Card style={{ textAlign: "center", marginBottom: 14, border: `1px solid ${band.color}55` }}>
                  <div style={{ fontSize: 12, color: C.muted }}>Overall risk across {scan.N} message{scan.N === 1 ? "" : "s"}</div>
                  <div style={{ fontSize: 26, fontWeight: 800, color: band.color, marginTop: 6 }}>{band.emoji} {band.label.toUpperCase()}</div>
                  <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>average score {scan.avg}/100</div>
                </Card>

                <div style={{ fontSize: 13, color: C.muted, margin: "4px 2px 10px" }}>Relationship Risk Analysis</div>
                {scan.cats.length === 0 && (
                  <Card style={{ marginBottom: 10 }}>
                    <p style={{ color: C.muted, fontSize: 13, margin: 0 }}>No concerning patterns matched across these messages.</p>
                  </Card>
                )}
                {scan.cats.map((c) => (
                  <div key={c.key} style={{ marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                      <span style={{ fontSize: 13, color: C.text, fontWeight: 600 }}>{c.label}</span>
                      <span style={{ fontSize: 13, fontWeight: 700, color: c.color }}>{c.pct}%</span>
                    </div>
                    <div style={{ height: 8, borderRadius: 8, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                      <div style={{ width: `${c.pct}%`, height: "100%", background: c.color }} />
                    </div>
                  </div>
                ))}
                <div style={{ marginBottom: 10, marginTop: 6 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                    <span style={{ fontSize: 13, color: C.text, fontWeight: 600 }}>Healthy Communication</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: "#10B981" }}>{scan.healthyPct}%</span>
                  </div>
                  <div style={{ height: 8, borderRadius: 8, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                    <div style={{ width: `${scan.healthyPct}%`, height: "100%", background: "#10B981" }} />
                  </div>
                </div>

                {scan.traumaBondFlag && (
                  <Card style={{ marginTop: 8, marginBottom: 14, borderLeft: `3px solid ${C.purple}` }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: C.purple, marginBottom: 6 }}>🔗 Possible trauma-bond cycle</div>
                    <p style={{ color: C.text, fontSize: 14, lineHeight: 1.55, margin: 0 }}>
                      Any single message here might be brushed off on its own. But taken together, these messages show
                      affection alternating with guilt, control, or withdrawal — the loving-then-cold pattern that can keep
                      someone hooked into a trauma bond.
                    </p>
                  </Card>
                )}

                <button onClick={() => nav("crisis")} style={{ width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 800, cursor: "pointer", marginTop: 4 }}>
                  Get support
                </button>
                <Card style={{ marginTop: 14 }}>
                  <p style={{ color: C.muted, fontSize: 12, lineHeight: 1.5, margin: 0 }}>
                    Pattern percentages reflect how often each pattern appears in the text you pasted — a reflection aid,
                    not a diagnosis. Only you, with support, can know your full situation. 💜
                  </p>
                </Card>
              </div>
            );
          })()}
        </>
      )}
    </div>
  );
}

// === No Contact Toolkit === (premium)
const NC_DAY = 86400000;
const ncMid = (d) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); };
const ncDaysSince = (iso) => (iso ? Math.max(0, Math.floor((ncMid(Date.now()) - ncMid(iso)) / NC_DAY)) : 0);
const ncDaysAgo = (iso) => Math.floor((Date.now() - new Date(iso).getTime()) / NC_DAY);
const ncStoredStart = () => { try { return JSON.parse(localStorage.getItem("yna_nc_start") || "null"); } catch { return null; } };

const NC_MILESTONES = [
  { d: 1, badge: "First Day", icon: "🌱" },
  { d: 7, badge: "One Week Strong", icon: "🔥" },
  { d: 14, badge: "Two Weeks Clear", icon: "💪" },
  { d: 30, badge: "One Month Free", icon: "🏆" },
  { d: 60, badge: "Sixty Days Steady", icon: "⭐" },
  { d: 90, badge: "Ninety Days Reclaimed", icon: "👑" },
  { d: 180, badge: "Half a Year Healed", icon: "🕊️" },
  { d: 365, badge: "One Year Free", icon: "🎉" },
];
const NC_WHY = ["I miss them", "I'm lonely", "I want closure", "They contacted me", "I saw them online", "I feel guilty", "Other"];
const NC_REALITY_DEFAULTS = ["They repeatedly broke promises", "They ignored my boundaries", "I felt anxious more than safe", "The relationship damaged my self-esteem"];
const NC_TRIGGER_TYPES = ["Loneliness", "Social media", "Anniversary", "Dream about them", "Argument memory", "Stress", "Family issues", "Boredom"];
const NC_MOODS = [
  { v: 5, emoji: "😀", label: "Great" },
  { v: 4, emoji: "🙂", label: "Good" },
  { v: 3, emoji: "😐", label: "Okay" },
  { v: 2, emoji: "😔", label: "Low" },
  { v: 1, emoji: "😭", label: "Struggling" },
];
const NC_AFFIRMATIONS = [
  "I deserve consistency.",
  "Missing them does not mean they were healthy for me.",
  "I can survive this feeling.",
  "My peace matters.",
  "The urge will pass whether I act on it or not.",
  "I am choosing me today.",
  "No contact is how I keep my power.",
  "I don't need closure from them to heal.",
];
const NC_PROMPTS = [
  "What do I need today that I was seeking from them?",
  "What would I tell a friend in my situation?",
  "What is one kind thing I can do for myself right now?",
  "What have I gained since going no contact?",
];

function ncScore({ current, moods, triggers, reasons, lessonsRead }) {
  const streakPts = Math.min(35, Math.round((current * 35) / 90));
  const recentMoods = moods.filter((m) => ncDaysAgo(m.date) <= 14).length;
  const journalPts = Math.min(20, recentMoods * 4);
  const last = moods.slice(-5);
  const avgMood = last.length ? last.reduce((s, m) => s + m.v, 0) / last.length : 0;
  const moodPts = Math.round((avgMood / 5) * 15);
  const recentTrig = triggers.filter((t) => ncDaysAgo(t.date) <= 14);
  let trigPts = 0;
  if (recentTrig.length) {
    const avgInt = recentTrig.reduce((s, t) => s + t.intensity, 0) / recentTrig.length;
    trigPts = Math.min(15, 6 + Math.round(10 - avgInt));
  }
  const reasonsPts = Math.min(8, reasons.length * 2);
  const lessonPts = Math.min(7, lessonsRead.length * 2);
  return Math.max(0, Math.min(100, streakPts + journalPts + moodPts + trigPts + reasonsPts + lessonPts));
}
const ncStatus = (s) => (s >= 80 ? "Reclaiming yourself" : s >= 60 ? "Healing & progressing" : s >= 40 ? "Building momentum" : "Finding your footing");

function NoContact({ nav, onSaveJournal }) {
  const [start, setStart] = useLS("yna_nc_start", null);
  const [longest, setLongest] = useLS("yna_nc_longest", 0);
  const [reasons, setReasons] = useLS("yna_nc_reasons", []);
  const [triggers, setTriggers] = useLS("yna_nc_triggers", []);
  const [moods, setMoods] = useLS("yna_nc_moods", []);
  const [contact, setContact] = useLS("yna_nc_contact", null);
  const [lessonsRead] = useLS("yna_lessons_read", []);

  const [view, setView] = useState("dashboard");

  // Start at day 0 on first open.
  useEffect(() => {
    if (!start) setStart(new Date().toISOString());
  }, []); // eslint-disable-line

  const current = ncDaysSince(start);
  const best = Math.max(longest, current);
  const score = ncScore({ current, moods, triggers, reasons, lessonsRead });
  const todayAff = NC_AFFIRMATIONS[ncDaysAgo("2020-01-01") % NC_AFFIRMATIONS.length];
  const todayPrompt = NC_PROMPTS[ncDaysAgo("2020-01-01") % NC_PROMPTS.length];

  const resetStreak = () => {
    setLongest(Math.max(longest, current));
    setStart(new Date().toISOString());
    setView("dashboard");
  };

  // ---- Urge interruption flow ----
  const [ustep, setUstep] = useState(1);
  const [usecs, setUsecs] = useState(60);
  const [uwhy, setUwhy] = useState([]);
  useEffect(() => {
    if (view !== "urge" || ustep !== 1) return;
    if (usecs <= 0) return;
    const t = setTimeout(() => setUsecs((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [view, ustep, usecs]);
  const openUrge = () => { setUstep(1); setUsecs(60); setUwhy([]); setView("urge"); };
  const toggleWhy = (w) => setUwhy(uwhy.includes(w) ? uwhy.filter((x) => x !== w) : [...uwhy, w]);

  // ---- SOS breathing ----
  const [breath, setBreath] = useState(0);
  const BREATHS = ["Breathe in…", "Hold…", "Breathe out…"];
  useEffect(() => {
    if (view !== "sos") return;
    const t = setInterval(() => setBreath((b) => (b + 1) % 3), 4000);
    return () => clearInterval(t);
  }, [view]);

  // ---- forms ----
  const [newReason, setNewReason] = useState("");
  const [newNote, setNewNote] = useState("");
  const addReason = () => {
    if (!newReason.trim()) return;
    setReasons([...reasons, { id: Date.now(), text: newReason.trim(), note: newNote.trim() }]);
    setNewReason(""); setNewNote("");
  };
  const delReason = (id) => setReasons(reasons.filter((r) => r.id !== id));

  const [trigTypes, setTrigTypes] = useState([]);
  const [trigInt, setTrigInt] = useState(5);
  const [trigSaved, setTrigSaved] = useState(false);
  const toggleTrig = (t) => setTrigTypes(trigTypes.includes(t) ? trigTypes.filter((x) => x !== t) : [...trigTypes, t]);
  const saveTrigger = () => {
    if (!trigTypes.length) return;
    setTriggers([...triggers, { date: new Date().toISOString(), types: trigTypes, intensity: trigInt }]);
    setTrigTypes([]); setTrigInt(5); setTrigSaved(true); setTimeout(() => setTrigSaved(false), 2000);
  };

  const [mood, setMood] = useState(null);
  const [moodNote, setMoodNote] = useState("");
  const [moodSaved, setMoodSaved] = useState(false);
  const saveMood = () => {
    if (mood == null) return;
    const m = NC_MOODS.find((x) => x.v === mood);
    const entry = { date: new Date().toISOString(), v: m.v, emoji: m.emoji, label: m.label, note: moodNote.trim() };
    setMoods([...moods, entry]);
    if (moodNote.trim() && onSaveJournal) onSaveJournal({ date: entry.date, text: `Mood: ${m.emoji} ${m.label}\n${moodNote.trim()}` });
    setMood(null); setMoodNote(""); setMoodSaved(true); setTimeout(() => setMoodSaved(false), 2000);
  };

  const [cName, setCName] = useState(contact?.name || "");
  const [cPhone, setCPhone] = useState(contact?.phone || "");

  const Back = () => (
    <button onClick={() => setView("dashboard")} style={{ background: "none", border: "none", color: C.lav, fontSize: 14, cursor: "pointer", padding: "0 0 12px", fontWeight: 700 }}>
      ‹ Toolkit
    </button>
  );

  // ===== Weekly trigger report =====
  const trigReport = (() => {
    const recent = triggers.filter((t) => ncDaysAgo(t.date) <= 7);
    if (!recent.length) return null;
    const counts = {}; const sums = {};
    recent.forEach((t) => t.types.forEach((ty) => { counts[ty] = (counts[ty] || 0) + 1; sums[ty] = (sums[ty] || 0) + t.intensity; }));
    const common = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
    const strongest = Object.keys(sums).sort((a, b) => sums[b] / counts[b] - sums[a] / counts[a])[0];
    const thisWk = recent.reduce((s, t) => s + t.intensity, 0) / recent.length;
    const prev = triggers.filter((t) => ncDaysAgo(t.date) > 7 && ncDaysAgo(t.date) <= 14);
    const prevWk = prev.length ? prev.reduce((s, t) => s + t.intensity, 0) / prev.length : null;
    const trend = prevWk == null ? "—" : thisWk < prevWk ? "improving ↓" : thisWk > prevWk ? "tougher ↑" : "steady →";
    return { common, strongest, trend, avg: thisWk.toFixed(1), n: recent.length };
  })();

  // ============ VIEWS ============
  if (view === "urge") {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Back />
        {ustep === 1 && (
          <Card style={{ textAlign: "center", padding: "32px 22px" }}>
            <div style={{ fontSize: 13, color: C.muted }}>Step 1 of 4</div>
            <div style={{ fontSize: 19, fontWeight: 800, color: C.text, marginTop: 6 }}>Pause for 60 seconds</div>
            <div style={{ fontSize: 56, fontWeight: 800, color: C.lav, margin: "16px 0" }}>{usecs}</div>
            <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.5 }}>The urge feels urgent, but it isn't. It will rise, peak, and fall on its own if you let it.</p>
            <button onClick={() => setUstep(2)} disabled={usecs > 0} style={{ marginTop: 14, width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 800, cursor: usecs > 0 ? "default" : "pointer", opacity: usecs > 0 ? 0.45 : 1 }}>
              {usecs > 0 ? "Breathe…" : "I made it — continue"}
            </button>
          </Card>
        )}
        {ustep === 2 && (
          <Card>
            <div style={{ fontSize: 13, color: C.muted }}>Step 2 of 4</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, margin: "6px 0 14px" }}>Why are you tempted?</div>
            {NC_WHY.map((w) => (
              <button key={w} onClick={() => toggleWhy(w)} style={{ display: "block", width: "100%", textAlign: "left", padding: "11px 14px", marginBottom: 8, borderRadius: 12, border: uwhy.includes(w) ? "1px solid transparent" : `1px solid ${C.border}`, background: uwhy.includes(w) ? G : C.card, color: C.text, fontSize: 14, cursor: "pointer" }}>
                {uwhy.includes(w) ? "☑ " : "☐ "}{w}
              </button>
            ))}
            <button onClick={() => setUstep(3)} style={{ marginTop: 8, width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 800, cursor: "pointer" }}>Continue</button>
          </Card>
        )}
        {ustep === 3 && (
          <Card>
            <div style={{ fontSize: 13, color: C.muted }}>Step 3 of 4</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, margin: "6px 0 6px" }}>Reality check</div>
            <p style={{ color: C.muted, fontSize: 13, marginTop: 0, marginBottom: 12 }}>What you told yourself in a clearer moment:</p>
            {(reasons.length ? reasons.map((r) => r.text) : NC_REALITY_DEFAULTS).map((r, i) => (
              <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8 }}>
                <span style={{ color: C.pink }}>•</span>
                <span style={{ color: C.text, fontSize: 14, lineHeight: 1.45 }}>{r}</span>
              </div>
            ))}
            <button onClick={() => setUstep(4)} style={{ marginTop: 10, width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 800, cursor: "pointer" }}>Continue</button>
          </Card>
        )}
        {ustep === 4 && (
          <Card>
            <div style={{ fontSize: 13, color: C.muted }}>Step 4 of 4</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: C.text, margin: "6px 0 14px" }}>Choose a healthier action</div>
            {[
              { label: "📓 Journal how I feel", go: () => setView("mood") },
              { label: "📖 Read my reasons", go: () => setView("reasons") },
              { label: "📚 Read a recovery lesson", go: () => nav("learn") },
              { label: "🎧 Grounding exercise", go: () => setView("sos") },
              { label: "💜 Talk to my Recovery Coach", go: () => nav("companion") },
            ].map((a, i) => (
              <button key={i} onClick={a.go} style={{ display: "block", width: "100%", textAlign: "left", padding: "12px 14px", marginBottom: 8, borderRadius: 12, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 14, cursor: "pointer" }}>{a.label}</button>
            ))}
            <button onClick={() => setView("dashboard")} style={{ marginTop: 10, width: "100%", padding: 14, borderRadius: 14, border: "none", background: G, color: C.text, fontSize: 15, fontWeight: 800, cursor: "pointer" }}>I stayed strong 💪</button>
          </Card>
        )}
      </div>
    );
  }

  if (view === "sos") {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Back />
        <Card style={{ textAlign: "center", padding: "30px 22px", marginBottom: 14 }}>
          <div style={{ fontSize: 30, fontWeight: 800, color: C.pink, letterSpacing: 1 }}>STOP.</div>
          <p style={{ color: C.text, fontSize: 16, lineHeight: 1.6, marginTop: 10 }}>This feeling is temporary. You do not need to act on it.</p>
          <div style={{ margin: "22px auto 10px", width: 120, height: 120, borderRadius: "50%", background: G, display: "flex", alignItems: "center", justifyContent: "center", transform: breath === 2 ? "scale(0.7)" : "scale(1)", transition: "transform 3.8s ease-in-out" }}>
            <span style={{ color: C.text, fontSize: 15, fontWeight: 700 }}>{BREATHS[breath]}</span>
          </div>
          <p style={{ color: C.muted, fontSize: 12 }}>Follow the circle. Three slow breaths.</p>
        </Card>
        {[
          { label: "📖 Read my reasons", go: () => setView("reasons") },
          { label: "💜 Talk to my Recovery Coach", go: () => nav("companion") },
          { label: "📝 Journal", go: () => setView("mood") },
        ].map((a, i) => (
          <button key={i} onClick={a.go} style={{ display: "block", width: "100%", textAlign: "left", padding: "13px 16px", marginBottom: 10, borderRadius: 14, border: `1px solid ${C.border}`, background: C.card, color: C.text, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>{a.label}</button>
        ))}
        {contact?.phone ? (
          <a href={`tel:${contact.phone}`} style={{ display: "block", textAlign: "center", padding: 13, marginBottom: 10, borderRadius: 14, background: G, color: C.text, fontSize: 14, fontWeight: 700, textDecoration: "none" }}>📞 Call {contact.name || "trusted contact"}</a>
        ) : (
          <Card style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 13, color: C.text, fontWeight: 700, marginBottom: 8 }}>📞 Add a trusted contact</div>
            <input value={cName} onChange={(e) => setCName(e.target.value)} placeholder="Name" style={{ width: "100%", padding: 10, borderRadius: 10, background: C.bg, border: `1px solid ${C.border}`, color: C.text, fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
            <input value={cPhone} onChange={(e) => setCPhone(e.target.value)} placeholder="Phone number" inputMode="tel" style={{ width: "100%", padding: 10, borderRadius: 10, background: C.bg, border: `1px solid ${C.border}`, color: C.text, fontSize: 13, marginBottom: 8, boxSizing: "border-box" }} />
            <button onClick={() => cPhone.trim() && setContact({ name: cName.trim(), phone: cPhone.trim() })} style={{ width: "100%", padding: 11, borderRadius: 10, border: "none", background: G, color: C.text, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>Save contact</button>
          </Card>
        )}
      </div>
    );
  }

  if (view === "reasons") {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Back />
        <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 4 }}>Reasons I left</div>
        <p style={{ color: C.muted, fontSize: 13, marginTop: 0, marginBottom: 14 }}>Your own words, for the moments the fog rolls in.</p>
        {reasons.map((r, i) => (
          <Card key={r.id} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
              <div style={{ flex: 1 }}>
                <div style={{ color: C.text, fontSize: 15, fontWeight: 600 }}>{i + 1}. {r.text}</div>
                {r.note && <div style={{ color: C.muted, fontSize: 13, marginTop: 4 }}>{r.note}</div>}
              </div>
              <button onClick={() => delReason(r.id)} style={{ background: "none", border: "none", color: C.muted, fontSize: 18, cursor: "pointer" }}>×</button>
            </div>
          </Card>
        ))}
        <Card>
          <input value={newReason} onChange={(e) => setNewReason(e.target.value)} placeholder="Add a reason…" style={{ width: "100%", padding: 11, borderRadius: 10, background: C.bg, border: `1px solid ${C.border}`, color: C.text, fontSize: 14, marginBottom: 8, boxSizing: "border-box" }} />
          <textarea value={newNote} onChange={(e) => setNewNote(e.target.value)} placeholder="Optional note / detail…" style={{ width: "100%", minHeight: 60, padding: 11, borderRadius: 10, background: C.bg, border: `1px solid ${C.border}`, color: C.text, fontSize: 14, marginBottom: 8, boxSizing: "border-box", fontFamily: "inherit" }} />
          <button onClick={addReason} style={{ width: "100%", padding: 12, borderRadius: 10, border: "none", background: G, color: C.text, fontSize: 14, fontWeight: 700, cursor: "pointer" }}>Add reason</button>
        </Card>
      </div>
    );
  }

  if (view === "triggers") {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Back />
        <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 14 }}>Trigger tracker</div>
        <Card style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: C.text, marginBottom: 10 }}>What triggered you today?</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
            {NC_TRIGGER_TYPES.map((t) => (
              <button key={t} onClick={() => toggleTrig(t)} style={{ padding: "8px 12px", borderRadius: 20, border: trigTypes.includes(t) ? "1px solid transparent" : `1px solid ${C.border}`, background: trigTypes.includes(t) ? G : C.card, color: C.text, fontSize: 13, cursor: "pointer" }}>{t}</button>
            ))}
          </div>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 6 }}>Intensity: <span style={{ color: C.lav, fontWeight: 700 }}>{trigInt}/10</span></div>
          <input type="range" min="1" max="10" value={trigInt} onChange={(e) => setTrigInt(Number(e.target.value))} style={{ width: "100%", accentColor: C.purple }} />
          <button onClick={saveTrigger} disabled={!trigTypes.length} style={{ marginTop: 12, width: "100%", padding: 12, borderRadius: 12, border: "none", background: G, color: C.text, fontSize: 14, fontWeight: 700, cursor: trigTypes.length ? "pointer" : "default", opacity: trigTypes.length ? 1 : 0.45 }}>{trigSaved ? "✓ Saved" : "Save trigger"}</button>
        </Card>
        <div style={{ fontSize: 13, color: C.muted, margin: "0 2px 10px" }}>This week</div>
        {trigReport ? (
          <Card>
            <Row k="Logged" v={`${trigReport.n} time${trigReport.n === 1 ? "" : "s"}`} />
            <Row k="Most common" v={trigReport.common} />
            <Row k="Strongest" v={trigReport.strongest} />
            <Row k="Avg intensity" v={`${trigReport.avg}/10`} />
            <Row k="Trend vs last week" v={trigReport.trend} last />
          </Card>
        ) : (
          <Card><p style={{ color: C.muted, fontSize: 13, margin: 0 }}>No triggers logged in the last 7 days. Logging them helps you see patterns.</p></Card>
        )}
      </div>
    );
  }

  if (view === "mood") {
    return (
      <div style={{ padding: "8px 20px 100px" }}>
        <Back />
        <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 14 }}>Recovery journal</div>
        <Card style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: C.text, marginBottom: 10 }}>Today's mood</div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
            {NC_MOODS.map((m) => (
              <button key={m.v} onClick={() => setMood(m.v)} style={{ background: "none", border: "none", cursor: "pointer", textAlign: "center", opacity: mood === m.v ? 1 : 0.45, transform: mood === m.v ? "scale(1.15)" : "none" }}>
                <div style={{ fontSize: 28 }}>{m.emoji}</div>
                <div style={{ fontSize: 10, color: C.muted }}>{m.label}</div>
              </button>
            ))}
          </div>
        </Card>
        <Card>
          <div style={{ fontSize: 13, color: C.lav, fontStyle: "italic", marginBottom: 10 }}>"{todayPrompt}"</div>
          <textarea value={moodNote} onChange={(e) => setMoodNote(e.target.value)} placeholder="Write here…" style={{ width: "100%", minHeight: 110, padding: 12, borderRadius: 12, background: C.bg, border: `1px solid ${C.border}`, color: C.text, fontSize: 14, marginBottom: 10, boxSizing: "border-box", fontFamily: "inherit" }} />
          <button onClick={saveMood} disabled={mood == null} style={{ width: "100%", padding: 12, borderRadius: 12, border: "none", background: G, color: C.text, fontSize: 14, fontWeight: 700, cursor: mood == null ? "default" : "pointer", opacity: mood == null ? 0.45 : 1 }}>{moodSaved ? "✓ Saved" : "Save entry"}</button>
          {mood == null && <div style={{ color: C.muted, fontSize: 11, textAlign: "center", marginTop: 8 }}>Pick a mood to save.</div>}
        </Card>
      </div>
    );
  }

  // ===== DASHBOARD =====
  return (
    <div style={{ padding: "8px 20px 100px" }}>
      <button onClick={openUrge} style={{ width: "100%", padding: 16, borderRadius: 16, border: "none", background: "linear-gradient(135deg,#EF4444,#F97316)", color: "#fff", fontSize: 16, fontWeight: 800, cursor: "pointer", marginBottom: 8 }}>
        🛑 I want to contact them
      </button>
      <button onClick={() => { setBreath(0); setView("sos"); }} style={{ width: "100%", padding: 13, borderRadius: 14, border: `1px solid ${C.pink}55`, background: "rgba(232,121,160,0.12)", color: C.text, fontSize: 14, fontWeight: 700, cursor: "pointer", marginBottom: 16 }}>
        🆘 SOS — I'm struggling right now
      </button>

      <Card style={{ textAlign: "center", marginBottom: 14 }}>
        <div style={{ fontSize: 12, color: C.muted }}>Days no contact</div>
        <div style={{ fontSize: 48, fontWeight: 800, color: C.text, lineHeight: 1.1, margin: "2px 0" }}>🔥 {current}</div>
        <div style={{ display: "flex", justifyContent: "center", gap: 18, marginTop: 8 }}>
          <div><div style={{ fontSize: 18, fontWeight: 800, color: C.lav }}>{current}</div><div style={{ fontSize: 11, color: C.muted }}>current</div></div>
          <div><div style={{ fontSize: 18, fontWeight: 800, color: C.gold }}>{best}</div><div style={{ fontSize: 11, color: C.muted }}>longest</div></div>
        </div>
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: C.text }}>Recovery score</span>
          <span style={{ fontSize: 14, fontWeight: 800, color: C.lav }}>{score}/100</span>
        </div>
        <div style={{ height: 8, borderRadius: 8, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
          <div style={{ width: `${score}%`, height: "100%", background: G }} />
        </div>
        <div style={{ fontSize: 12, color: C.muted, marginTop: 8 }}>Status: {ncStatus(score)}</div>
      </Card>

      <Card style={{ marginBottom: 14, background: "rgba(232,121,160,0.12)", textAlign: "center" }}>
        <div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>Today's affirmation</div>
        <p style={{ color: C.text, fontSize: 15, fontStyle: "italic", margin: 0 }}>"{todayAff}"</p>
      </Card>

      <div style={{ fontSize: 13, color: C.muted, margin: "4px 2px 10px" }}>Milestones</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
        {NC_MILESTONES.map((m) => {
          const got = best >= m.d;
          return (
            <Card key={m.d} style={{ textAlign: "center", padding: 14, opacity: got ? 1 : 0.4, border: got ? `1px solid ${C.gold}55` : `1px solid ${C.border}` }}>
              <div style={{ fontSize: 24 }}>{got ? m.icon : "🔒"}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: C.text, marginTop: 4 }}>{m.badge}</div>
              <div style={{ fontSize: 11, color: C.muted }}>{m.d} day{m.d === 1 ? "" : "s"}</div>
            </Card>
          );
        })}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {[
          { label: "Reasons I left", emoji: "📖", go: () => setView("reasons") },
          { label: "Trigger tracker", emoji: "📊", go: () => setView("triggers") },
          { label: "Recovery journal", emoji: "📓", go: () => setView("mood") },
          { label: "Grounding / SOS", emoji: "🎧", go: () => { setBreath(0); setView("sos"); } },
        ].map((t) => (
          <Card key={t.label} onClick={t.go} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 24 }}>{t.emoji}</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: C.text, marginTop: 4 }}>{t.label}</div>
          </Card>
        ))}
      </div>

      <div style={{ textAlign: "center", marginTop: 16, display: "flex", flexDirection: "column", gap: 8 }}>
        <button onClick={() => { const d = prompt("Set your no-contact start date (YYYY-MM-DD):", new Date(start || Date.now()).toISOString().slice(0, 10)); if (d && !isNaN(new Date(d))) setStart(new Date(d).toISOString()); }} style={{ background: "none", border: "none", color: C.muted, fontSize: 12, cursor: "pointer" }}>
          Edit start date
        </button>
        <button onClick={() => { if (window.confirm("Had contact and want to reset the streak? Your longest streak is kept.")) resetStreak(); }} style={{ background: "none", border: "none", color: C.muted, fontSize: 12, cursor: "pointer" }}>
          Had contact? Reset streak
        </button>
      </div>
    </div>
  );
}

// Small key/value row used in the trigger report.
function Row({ k, v, last }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: last ? "none" : `1px solid ${C.border}` }}>
      <span style={{ color: C.muted, fontSize: 13 }}>{k}</span>
      <span style={{ color: C.text, fontSize: 13, fontWeight: 700 }}>{v}</span>
    </div>
  );
}

const NAV = [
  { id: "home", emoji: "🏠" },
  { id: "learn", emoji: "📚" },
  { id: "affirm", emoji: "✨" },
  { id: "companion", emoji: "💜" },
];

const TITLES = {
  crisis: "Crisis Resources",
  learn: "Education Hub",
  assessment: "Trauma Bond Check",
  detector: "Red Flag Detector",
  nocontact: "No Contact Toolkit",
  stages: "Your Healing Stage",
  journal: "Journal",
  affirm: "Affirmations",
  companion: "AI Recovery Coach",
  paywall: "Premium",
  account: "Account",
};

export default function App() {
  const [history, setHistory] = useState(["home"]);
  const screen = history[history.length - 1];

  // Premium state. With RevenueCat configured, the entitlement is the source of truth;
  // otherwise we fall back to a local flag so the gated screens are testable.
  const [localPremium, setLocalPremium] = useLS("yna_premium", false);
  const [rc, setRc] = useState(null);
  const [rcPremium, setRcPremium] = useState(false);
  const [offerings, setOfferings] = useState(null);
  const premium = REVENUECAT_WEB_KEY ? rcPremium : localPremium;

  // Auth (optional). supabase stays null when not configured → app runs anonymously.
  const [supabase, setSupabase] = useState(null);
  const [session, setSession] = useState(null);

  useEffect(() => {
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return;
    let active = true;
    let sub;
    (async () => {
      try {
        const { createClient } = await import("@supabase/supabase-js");
        const client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        if (!active) return;
        setSupabase(client);
        const { data } = await client.auth.getSession();
        if (!active) return;
        setSession(data.session || null);
        sub = client.auth.onAuthStateChange((_e, s) => setSession(s)).data.subscription;
      } catch (e) {
        console.error("Supabase init failed:", e);
      }
    })();
    return () => {
      active = false;
      if (sub) sub.unsubscribe();
    };
  }, []);

  // Keep RevenueCat's identity in step with the signed-in user so entitlements follow them.
  useEffect(() => {
    if (!rc) return;
    let active = true;
    const uid = session?.user?.id || getAppUserId();
    (async () => {
      try {
        const info = await rc.changeUser(uid);
        if (!active) return;
        setRcPremium(PREMIUM_ENTITLEMENT in info.entitlements.active);
      } catch (e) {
        console.error("RevenueCat changeUser failed:", e);
      }
    })();
    return () => {
      active = false;
    };
  }, [rc, session]);

  useEffect(() => {
    if (!REVENUECAT_WEB_KEY) return;
    let active = true;
    (async () => {
      try {
        const mod = await import("@revenuecat/purchases-js");
        const Purchases = mod.Purchases || mod.default;
        const purchases = Purchases.configure({ apiKey: REVENUECAT_WEB_KEY, appUserId: getAppUserId() });
        if (!active) return;
        setRc(purchases);
        const info = await purchases.getCustomerInfo();
        if (!active) return;
        setRcPremium(PREMIUM_ENTITLEMENT in info.entitlements.active);
        const offs = await purchases.getOfferings();
        if (!active) return;
        setOfferings(offs.current);
      } catch (e) {
        console.error("RevenueCat init failed:", e);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const handleUnlock = async () => {
    if (rc) {
      try {
        const info = await rc.getCustomerInfo();
        setRcPremium(PREMIUM_ENTITLEMENT in info.entitlements.active);
      } catch {}
    } else {
      setLocalPremium(true);
    }
    back();
  };

  const [stage, setStage] = useLS("yna_stage", 1);
  const [checkins] = useLS("yna_checkins", []);
  const [entries, setEntries] = useLS("yna_journal", []);
  const [tbResult, setTbResult] = useLS("yna_tb_result", null);

  const nav = (s) => setHistory((h) => [...h, s]);
  const back = () => setHistory((h) => (h.length > 1 ? h.slice(0, -1) : h));
  const goPaywall = () => nav("paywall");
  const addEntry = (e) => setEntries([...entries, e]);

  // Screens that require premium; free users see the soft lock instead.
  const gated = {
    companion: { feature: "The Recovery Coach", blurb: "Talk any time with an AI coach across four modes — daily support, urge-surfing, learning the patterns, and guided reflection." },
    nocontact: { feature: "The No Contact Toolkit", blurb: "Track your streak, interrupt the urge to reach out, log triggers, and build a recovery score — your daily anchor for staying no-contact." },
    journal: { feature: "The Journal", blurb: "Write freely and keep your full history as you heal." },
    stages: { feature: "Stage tracking", blurb: "Track where you are and watch yourself move forward." },
  };

  const renderScreen = () => {
    if (screen === "home") return <Home nav={nav} stage={stage} checkins={checkins} premium={premium} tbResult={tbResult} />;
    if (screen === "crisis") return <Crisis />;
    if (screen === "learn") return <Learn nav={nav} />;
    if (screen === "assessment") return <Assessment nav={nav} onSave={setTbResult} />;
    if (screen === "detector") return <Detector nav={nav} premium={premium} goPaywall={goPaywall} onSaveJournal={addEntry} />;
    if (screen === "affirm") return <Affirm premium={premium} goPaywall={goPaywall} />;
    if (screen === "paywall") return <Paywall onUnlock={handleUnlock} rc={rc} offerings={offerings} />;
    if (screen === "account") return <Account supabase={supabase} session={session} onSignedOut={() => setSession(null)} />;

    if (gated[screen] && !premium) {
      return <PremiumLock feature={gated[screen].feature} blurb={gated[screen].blurb} goPaywall={goPaywall} />;
    }
    if (screen === "companion") return <Companion stage={stage} authToken={session?.access_token} nav={nav} />;
    if (screen === "journal") return <Journal entries={entries} onSave={addEntry} />;
    if (screen === "stages") return <Stages stage={stage} setStage={setStage} />;
    if (screen === "nocontact") return <NoContact nav={nav} onSaveJournal={addEntry} />;
    return null;
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "sans-serif", maxWidth: 480, margin: "0 auto", position: "relative" }}>
      <div style={{ position: "relative", zIndex: 1 }}>
        {screen !== "home" && <TopBar title={TITLES[screen] || ""} onBack={back} premium={premium} />}
        {renderScreen()}
      </div>

      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: "rgba(15,10,30,0.95)", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-around", padding: "10px 0", zIndex: 10 }}>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => (n.id === "home" ? setHistory(["home"]) : nav(n.id))} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 24, opacity: screen === n.id ? 1 : 0.4 }}>
            {n.emoji}
          </button>
        ))}
      </div>
    </div>
  );
}
