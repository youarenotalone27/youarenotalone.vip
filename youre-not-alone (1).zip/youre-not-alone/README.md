# You're Not Alone

A web app for healing from toxic relationships.

This folder is a complete project. Below are plain-English steps to get it
online. Do them in order. You only need to do this once.

------------------------------------------------------------------------
## STEP 1 — Put this code on GitHub
------------------------------------------------------------------------

1. Go to github.com and log in.
2. Click the "+" (top right) -> "New repository".
3. Name it: youre-not-alone   ->  click "Create repository".
4. Open THIS folder on your computer.
5. Right-click inside it -> "Open in Terminal" (Mac) or "Git Bash Here" (Windows).
6. Paste these lines one at a time, pressing Enter after each.
   Replace YOUR_USERNAME with your real GitHub username:

   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/youre-not-alone.git
   git push -u origin main

Your code is now on GitHub.

------------------------------------------------------------------------
## STEP 2 — Put it online with Vercel
------------------------------------------------------------------------

1. Go to vercel.com and log in (you can log in WITH your GitHub account).
2. Click "Add New" -> "Project".
3. Find "youre-not-alone" in the list -> click "Import".
4. Leave all the build settings as they are (Vercel knows what to do).
5. BEFORE clicking Deploy, open "Environment Variables" and add ONE:
       Name:  ANTHROPIC_API_KEY
       Value: (your Claude API key, starts with sk-ant-)
   This is what makes the Recovery Coach work. Keep it secret.
6. Click "Deploy". Wait ~2 minutes.
7. You'll get a live web address ending in .vercel.app — open it and check it works.

------------------------------------------------------------------------
## STEP 3 — Connect your own domain
------------------------------------------------------------------------

1. In your Vercel project: Settings -> Domains.
2. Type your domain (e.g. yourdomain.com) -> Add.
3. Vercel shows you DNS records. Go to where you bought your domain
   and enter those records exactly as shown.
4. Wait for it to verify (minutes to a few hours). Done — HTTPS is automatic.

------------------------------------------------------------------------
## STEP 4 — Turn on payments (do this LAST, when you're ready)
------------------------------------------------------------------------

Until you do this, the app runs in "test mode": the Premium features
unlock for free so you can try them. To charge real money:

1. Set up RevenueCat (account, connect Stripe, create a "premium"
   entitlement, create an Offering with monthly/annual/lifetime packages).
2. Copy your RevenueCat WEB key (it starts with: rcb_ ).
3. Open the file:  src/App.js
4. Find this line near the top:

       const REVENUECAT_WEB_KEY = "";

   Paste your key between the quotes:

       const REVENUECAT_WEB_KEY = "rcb_yourkeyhere";

5. Save, then push the change to GitHub:

       git add .
       git commit -m "Add RevenueCat key"
       git push

   Vercel will automatically update your live site.

------------------------------------------------------------------------
## What's free vs paid (current setup)
------------------------------------------------------------------------
FREE:    Crisis Resources, Trauma Bond Check, Red Flag Detector, basic affirmations
PREMIUM: Recovery Coach, No Contact Toolkit, Journal, full affirmations, stage tracker

------------------------------------------------------------------------
## The keys, in one place
------------------------------------------------------------------------
ANTHROPIC_API_KEY  -> goes in Vercel (Environment Variables). Powers the coach.
REVENUECAT_WEB_KEY -> goes in src/App.js. Powers payments. (optional until launch)
SUPABASE (optional)-> only if you want logins/cross-device sync. Set SUPABASE_URL
                      and SUPABASE_ANON_KEY in src/App.js. App works fine without it.
