// api/chat.js
// Server-side proxy between the "You're Not Alone" app and the Anthropic Messages API.
//
// WHY THIS EXISTS
//   The Anthropic API key must NEVER ship in client code. The browser calls THIS endpoint
//   (CHAT_API_URL = "/api/chat" in the app); this function adds the key server-side and
//   forwards the request to Anthropic. The key stays in your hosting platform's env vars.
//
// DEPLOY (Vercel / Next.js style — matches the relative "/api/chat" path the app uses)
//   1. Put this file at /api/chat.js in your project (Vercel) or app/api/chat/route.js
//      style if you prefer the App Router (see note at bottom).
//   2. In your hosting dashboard set env vars (see ENV below). At minimum ANTHROPIC_API_KEY.
//   3. Deploy. Node 18+ is required (this uses the built-in global fetch).
//   No npm dependencies are needed.
//
// ENV VARS
//   ANTHROPIC_API_KEY   (required)  Your secret key, starts with "sk-ant-".
//   ANTHROPIC_MODEL     (optional)  Default "claude-sonnet-4-6". Use "claude-haiku-4-5"
//                                   for lower cost, "claude-opus-4-8" for max quality.
//   ALLOWED_ORIGIN      (optional)  e.g. "https://yourapp.com". Locks CORS to your site.
//                                   Leave unset during local dev to allow all origins.
//   REQUIRE_AUTH        (optional)  "true" to reject requests without a valid Supabase JWT.
//                                   Leave unset to keep the app anonymous-first (recommended
//                                   so someone in crisis isn't blocked by a login wall).
//   SUPABASE_URL        (optional)  Needed only if you verify Supabase tokens.
//   SUPABASE_ANON_KEY   (optional)  Needed only if you verify Supabase tokens.
//
// SECURITY NOTE — open relay
//   This endpoint can be called by anyone who finds the URL. The guards below (origin check,
//   input caps, rate limit, a server-side safety wrapper, optional auth) make casual abuse
//   expensive and keep the model in its supportive lane even if a caller sends a hostile
//   "system" prompt. For stronger protection, set REQUIRE_AUTH=true, or move the coach
//   prompts (COACH_BASE + COACH_MODES) into THIS file and have the client send only a
//   { mode, messages } pair so callers can never supply an arbitrary system prompt.
//
// PRIVACY NOTE
//   This is mental-health data. We deliberately do NOT log message contents. Keep it that way.

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_VERSION = "2023-06-01";
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-6";
const MAX_TOKENS = 768; // coach replies are short (2–4 sentences); keeps cost/abuse down

// Caps on what a single request may contain.
const MAX_MESSAGES = 40;
const MAX_TOTAL_CHARS = 24000; // across all message contents
const MAX_SYSTEM_CHARS = 8000;

// A safety preamble prepended to whatever system prompt the client sends. Even under abuse,
// this keeps the assistant from being turned into a general-purpose / harmful tool.
const SERVER_GUARD =
  "You are a supportive wellbeing assistant for an app that helps people recover from toxic, " +
  "narcissistic, or emotionally abusive relationships. Stay strictly within emotional support, " +
  "psychoeducation about relationship patterns, and gentle reflection. You are not a therapist " +
  "and do not give medical, legal, or crisis instructions. Refuse unrelated requests (coding, " +
  "general knowledge, content generation) by gently redirecting to the person's feelings. If the " +
  "person mentions being in danger or thoughts of self-harm, encourage them to use the app's " +
  "Crisis Resources or contact local emergency services. Keep replies brief and kind.";

// --- very small in-memory rate limiter (per IP) -----------------------------------------
// NOTE: resets on cold start and is per-instance. For real protection use a shared store
// (Upstash Redis, Vercel KV, etc.). This just blunts trivial floods.
const RATE = { windowMs: 60_000, max: 20 };
const hits = new Map(); // ip -> number[] (timestamps)
function rateLimited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < RATE.windowMs);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) hits.clear(); // crude memory cap
  return arr.length > RATE.max;
}

function setCors(res, origin) {
  const allow = process.env.ALLOWED_ORIGIN;
  res.setHeader("Access-Control-Allow-Origin", allow || origin || "*");
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
}

// Optional: verify a Supabase access token by asking Supabase who it belongs to.
async function verifySupabaseToken(token) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) return null;
  if (!token) return null;
  try {
    const r = await fetch(`${process.env.SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: process.env.SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
    });
    if (!r.ok) return null;
    const user = await r.json();
    return user?.id ? user : null;
  } catch {
    return null;
  }
}

export default async function handler(req, res) {
  const origin = req.headers.origin;
  setCors(res, origin);

  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "Server not configured" });
  }

  // If an explicit origin allowlist is set, enforce it.
  if (process.env.ALLOWED_ORIGIN && origin && origin !== process.env.ALLOWED_ORIGIN) {
    return res.status(403).json({ error: "Forbidden origin" });
  }

  const ip =
    (req.headers["x-forwarded-for"] || "").split(",")[0].trim() ||
    req.socket?.remoteAddress ||
    "unknown";
  if (rateLimited(ip)) {
    return res.status(429).json({ error: "Too many requests — please slow down." });
  }

  // Body may arrive parsed (Vercel/Next) or as a raw string. Handle both.
  let body = req.body;
  if (typeof body === "string") {
    try {
      body = JSON.parse(body);
    } catch {
      return res.status(400).json({ error: "Invalid JSON" });
    }
  }
  body = body || {};

  // Optional auth.
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  const user = await verifySupabaseToken(token);
  if (process.env.REQUIRE_AUTH === "true" && !user) {
    return res.status(401).json({ error: "Authentication required" });
  }

  // Validate messages.
  const messages = Array.isArray(body.messages) ? body.messages : null;
  if (!messages || messages.length === 0) {
    return res.status(400).json({ error: "messages must be a non-empty array" });
  }
  if (messages.length > MAX_MESSAGES) {
    return res.status(400).json({ error: "Conversation too long" });
  }

  let totalChars = 0;
  const clean = [];
  for (const m of messages) {
    if (!m || (m.role !== "user" && m.role !== "assistant")) {
      return res.status(400).json({ error: "Invalid message role" });
    }
    if (typeof m.content !== "string") {
      return res.status(400).json({ error: "Message content must be a string" });
    }
    totalChars += m.content.length;
    clean.push({ role: m.role, content: m.content });
  }
  if (totalChars > MAX_TOTAL_CHARS) {
    return res.status(400).json({ error: "Message content too large" });
  }

  // System prompt: cap length, then wrap with the server guard so it can't be overridden.
  const clientSystem =
    typeof body.system === "string" ? body.system.slice(0, MAX_SYSTEM_CHARS) : "";
  const system = `${SERVER_GUARD}\n\n${clientSystem}`.trim();

  try {
    const upstream = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": ANTHROPIC_VERSION,
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: MAX_TOKENS,
        system,
        messages: clean,
      }),
    });

    if (!upstream.ok) {
      // Don't leak upstream error details to the client.
      const status = upstream.status === 429 ? 429 : 502;
      return res.status(status).json({ error: "Upstream error" });
    }

    const data = await upstream.json();
    const reply = Array.isArray(data.content)
      ? data.content
          .filter((b) => b.type === "text")
          .map((b) => b.text)
          .join("\n")
          .trim()
      : "";

    if (!reply) return res.status(502).json({ error: "Empty reply" });
    return res.status(200).json({ reply });
  } catch {
    // No message content logged on purpose.
    return res.status(502).json({ error: "Failed to reach the assistant" });
  }
}

// --- Notes for other hosts ---------------------------------------------------------------
// Next.js App Router (app/api/chat/route.js): export an async POST(request) that reads
//   await request.json(), and return new Response(JSON.stringify({reply}), {status, headers}).
//   The validation/guard logic above transfers directly.
// Netlify Functions / Cloudflare Workers: same logic; adapt the (req,res) signature to the
//   platform's Request/Response objects.
// Express: app.post("/api/chat", express.json(), (req,res)=>{ ...the body of handler... }).
